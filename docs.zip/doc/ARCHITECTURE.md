# System Architecture & Technical Specification

**Project**: DreamWithTech Billing ERP  
**Architecture Type**: Decoupled Cloud Native / RESTful Microservices & Single Page Applications (SPA)  
**Backend Framework**: Django 4.2.16 + Django REST Framework 3.15+  
**Frontend Frameworks**:  
- Store POS & Merchant Portal: React 19 + Vite 8 + Tailwind CSS v4 (`frontend/`)  
- Central Company Admin Dashboard: React 19 + Vite 6 + React Router 7 + Pure CSS Modules (`admin-frontend/`)  
**Database**: PostgreSQL 15+ (Production) / SQLite3 (Development)  
**Cloud Storage**: Supabase S3-compatible Storage with local media fallback  
**Payment & Communications**: Razorpay Gateway SDK, Twilio WhatsApp / SMS API  

---

## 1. High-Level Architectural Blueprint

```mermaid
flowchart TB
    subgraph Clients["Presentation Layer (Client Applications)"]
        POSApp["Merchant POS & ERP (React 19 + Tailwind v4)\nPort 5173 · app.dreamwithtech.dev"]
        AdminApp["Company Admin Portal (React 19 + CSS Modules)\nPort 5174 · admin.dreamwithtech.dev"]
        PublicApp["Customer Public Bill Viewer\napp.dreamwithtech.dev/bill/:token"]
    end

    subgraph Edge["Network, Reverse Proxy & Security"]
        Nginx["Nginx Reverse Proxy / Cloudflare SSL"]
        WhiteNoise["WhiteNoise Static Engine (Brotli/Gzip)"]
    end

    subgraph BackendApp["API Application Layer (Django 4.2 + DRF)"]
        AuthModule["SimpleJWT & OTP Auth\nSHA-256 Verification"]
        POSService["Invoice & Inventory Lock Engine\nAtomic Concurrency"]
        LedgerService["Double-Entry Ledger Engine\nCustomer & Supplier Ledgers"]
        PDFService["ReportLab Document Engine\nA4 & Thermal 80mm/58mm"]
        NotifService["Notification & Alert Worker\nTwilio & In-App Alerts"]
        Calculations["Pure Functional Math Engine\nStatutory GST Splits"]
    end

    subgraph Persistence["Storage & External Service Integrations"]
        DB[("PostgreSQL Database\nRow Constraints & Multi-Tenancy")]
        Supabase["Supabase Object Storage\nInvoice Archiving & Logos"]
        RazorpayGateway["Razorpay Payment Gateway\nAutoPay Mandates & Webhooks"]
        TwilioAPI["Twilio Communications API\nWhatsApp & SMS Dispatch"]
    end

    POSApp --> Nginx
    AdminApp --> Nginx
    PublicApp --> Nginx

    Nginx --> WhiteNoise
    Nginx --> BackendApp

    BackendApp --> DB
    BackendApp --> Supabase
    BackendApp --> RazorpayGateway
    BackendApp --> TwilioAPI
```

---

## 2. Directory Structure & Code Organization

```
billing_erp/
├── backend/                       # Django 4.2 RESTful API Server
│   ├── api/                       # Primary ERP Domain Application
│   │   ├── management/commands/   # Seeding scripts, cron sync, inventory audits
│   │   ├── migrations/            # Schema version migrations (0001 - 0039+)
│   │   ├── services/              # Encapsulated Business Logic Services
│   │   │   ├── invoice_service.py # Atomic invoice creation, pricing & stock deduction
│   │   │   ├── notification_service.py # Event alerts, threshold triggers
│   │   │   └── payment_service.py # Payment collection, permanent Transaction ID logic
│   │   ├── calculations.py        # Pure functional tax & gross/net profit calculators
│   │   ├── models.py              # Relational models, constraints, and custom managers
│   │   ├── pagination.py          # Standard pagination & limit-offset paginators
│   │   ├── pdf_utils.py           # ReportLab PDF invoice generator (A4 & Thermal)
│   │   ├── permissions.py         # Role-based access control (RBAC) classes
│   │   ├── serializers.py         # DRF serializers, nested inputs, validators
│   │   ├── supabase_storage.py    # Cloud storage adapter with local filesystem fallback
│   │   ├── urls.py                # ViewSet routers & custom API route definitions
│   │   ├── utils.py               # Short link generator, IP resolver, cryptographic helpers
│   │   └── views.py               # ViewSets, APIViews, report aggregation endpoints
│   ├── core/                      # Django Core Configuration
│   │   ├── settings.py            # Environment configurations, database routing, JWT
│   │   ├── urls.py                # Root router, media routes, public short link resolver
│   │   └── wsgi.py                # WSGI entrypoint for Gunicorn
│   ├── media/                     # Local fallback storage (receipts, brand logos)
│   ├── requirements.txt           # Python backend dependencies
│   └── manage.py                  # Django CLI utility
│
├── frontend/                      # Store POS & Merchant Management SPA
│   ├── src/
│   │   ├── assets/                # Static graphics, placeholder assets
│   │   ├── components/            # Reusable UI & Structural Components
│   │   │   ├── layout/            # Layout.jsx (Topbar, Sidebar, Responsive Drawer)
│   │   │   ├── InvoiceDocument.jsx# Thermal & A4 printable preview templates
│   │   │   ├── BarcodePrintModal.jsx # Sticker sheet & roll label generator
│   │   │   └── UI.jsx             # Button, Badge, Modal, ConfirmDialog, Table primitives
│   │   ├── features/billing/      # POS Billing Feature Module
│   │   │   ├── api/invoiceService.js # Billing endpoint client calls
│   │   │   └── RazorpayPaymentModal.jsx # Dynamic UPI QR & status poller
│   │   ├── pages/                 # 26 Core Business Route Pages
│   │   │   ├── NewBill.jsx        # POS High-Speed Checkout Screen
│   │   │   ├── Dashboard.jsx      # Executive KPI Metrics & Trend Heatmaps
│   │   │   ├── Bills.jsx          # Historical Invoices & Action Directory
│   │   │   ├── Products.jsx       # Master Product & SKU Catalog
│   │   │   ├── Inventory.jsx      # Stock Adjustments & CSV Batch Import
│   │   │   ├── Customers.jsx      # Customer Khata & Balance Directory
│   │   │   ├── Purchases.jsx      # Inbound Supplier POs & Inwarding
│   │   │   ├── Reports.jsx        # Sales, Gross Margin & GSTR-1 Analytics
│   │   │   ├── Settings.jsx       # Store Identity, Receipt & Printer Config
│   │   │   └── PublicBill.jsx     # Customer-Facing Digital Receipt View
│   │   ├── utils/
│   │   │   └── formatters.js      # Centralized Indian Number & Currency Formatters
│   │   ├── App.jsx                # Router, Toast Provider, Keyboard Listener
│   │   └── main.jsx               # React 19 Root Mount
│   ├── vite.config.js             # Vite 8 + Tailwind v4 Bundler Configuration
│   └── package.json               # Frontend dependencies
│
├── admin-frontend/                # Central Company Admin Dashboard (SaaS Operations)
│   ├── src/
│   │   ├── components/            # Isolated UI, Tables, Layout, and Recharts Charts
│   │   ├── layouts/AdminLayout.jsx# Enterprise Navy-Slate Layout Shell
│   │   ├── pages/                 # 28 Standalone Administrative Pages
│   │   │   ├── Dashboard.jsx      # Platform MRR, ARR, and Growth Overview
│   │   │   ├── Shops.jsx          # Tenant Directory with 7-Char Shop ID Search
│   │   │   ├── ShopDetails.jsx    # 360° Merchant View across 5 Tabs
│   │   │   ├── AddShop.jsx        # Onboarding Form with Live DWAAYYNN Generator
│   │   │   ├── Plans.jsx          # Subscription Tiers & Feature Gates
│   │   │   ├── Payments.jsx       # Platform Billing Invoices & Tax Schedules
│   │   │   ├── Transactions.jsx   # Double-Entry Platform Financial Ledger
│   │   │   ├── Refunds.jsx        # Subscription Disputes & Reversals
│   │   │   └── Support.jsx        # Helpdesk Ticketing Queue & Reply Drawer
│   │   ├── services/adminService.js# LocalStorage Persistence & Mock Repository
│   │   ├── styles/                # Pure CSS (variables, layout, tables, components)
│   │   ├── utils/formatters.js    # Indian Numbering Standards
│   │   ├── App.jsx                # Admin BrowserRouter & ToastProvider
│   │   └── main.jsx               # React 19 Root Mount
│   ├── vite.config.js             # Vite 6 with Vendor Chunk Optimization
│   └── package.json               # React Router 7, Recharts, Lucide React
│
└── docs/                          # Comprehensive Architectural & Technical Documentation
    ├── PRD.md                     # Product Requirements Document
    ├── ARCHITECTURE.md            # System Architecture & Technical Reference (This File)
    ├── RULES.md                   # Development Rules & Coding Standards
    ├── DESIGN.md                  # Design System, Palette & UI/UX Guidelines
    ├── TASKS.md                   # Implementation Status, Completed & Roadmap Tasks
    └── MEMORY.md                  # Project Memory & Key Architectural Decisions
```

---

## 3. Database Schema & Relational Models

The relational schema is enforced via PostgreSQL check constraints to prevent corrupt accounting records, negative stock balances, or invalid GST rates.

```mermaid
erDiagram
    Business ||--o{ User : employs
    Business ||--o{ Product : owns
    Business ||--o{ Customer : registers
    Business ||--o{ Supplier : contracts
    Business ||--o{ Purchase : executes
    Business ||--o{ Invoice : issues
    Business ||--o{ Expense : logs
    Business ||--o{ Notification : generates

    Customer ||--o{ CustomerLedger : records
    Customer ||--o{ CustomerPayment : makes
    Customer ||--o{ Invoice : billed_to

    Supplier ||--o{ SupplierLedger : records
    Supplier ||--o{ SupplierPayment : receives
    Supplier ||--o{ Purchase : fulfills

    Purchase ||--|{ PurchaseItem : contains
    Invoice ||--|{ InvoiceItem : contains
    Invoice ||--o{ Payment : receives
    Invoice ||--o{ SalesReturn : returns
    Invoice ||--o{ RazorpayTransaction : gateway

    Product ||--o{ InvoiceItem : references
    Product ||--o{ PurchaseItem : references
    Product ||--o{ InventoryTransaction : tracks
```

### Key Models Breakdown

#### 1. `Business` (Multi-Tenant Root)
- `id`: UUID primary key.
- `shop_id`: Unique 7-character Shop ID (`DWAAYYNN`), indexed and immutable.
- `name`: Store business name.
- `owner_name`, `mobile`, `email`, `address`.
- `gstin`, `pan`: Statutory tax identifiers.
- `invoice_prefix`: Configurable prefix (default: `"INV"`).
- `invoice_start_number`: Sequential starting integer (default: `1001`).
- `currency`: Default currency symbol (`"₹"`).
- `tax_enabled`: Global GST switch flag.

#### 2. `RetiredShopID`
- Tracks all deleted or decommissioned Shop IDs.
- Contains `shop_id` (`CharField(max_length=7, unique=True)`), `retired_at`, and `original_business_name`.
- Enforces permanent non-reusability across the entire platform lifecycle.

#### 3. `User` (Subclass of `AbstractUser`)
- Multi-role field: `owner`, `admin`, `manager`, `cashier`, `accountant`.
- Scoped to `Business` via Foreign Key (`on_delete=CASCADE`).
- Failed login attempt counter with automatic account lockout threshold.

#### 4. `Product` & `ProductBatch`
- `barcode`: Indexed unique barcode (UPC/EAN/Code128).
- `sku`: Internal item SKU.
- `hsn_code`: Statutory Harmonized System of Nomenclature code.
- `cost_price`, `selling_price`, `mrp`: Decimal financial figures.
- `tax_rate`: GST slab percentage (`0.00`, `5.00`, `12.00`, `18.00`, `28.00`).
- `is_tax_inclusive`: Boolean flag determining backward or forward tax computation.
- `current_stock`, `min_stock_alert`: Integer inventory counts.
- `ProductBatch`: Handles batch numbers, manufacturing dates, and expiration dates.

#### 5. `Invoice` & `InvoiceItem`
- `invoice_number`: Canonical human-readable invoice code (e.g., `INV-26-1045`).
- `customer`: Optional Foreign Key to `Customer` (supports Walk-In / Cash customers).
- `subtotal`, `tax_amount`, `discount_amount`, `round_off`, `grand_total`: Strict `Decimal(12, 2)`.
- `cgst_amount`, `sgst_amount`, `igst_amount`: Statutory tax splits.
- `payment_status`: `paid`, `partial`, `unpaid`, `cancelled`, `refunded`.
- `public_token`: 24-byte cryptographic token for the public bill viewer.
- `InvoiceItem`: Line item capturing `product`, `quantity`, `unit_price`, `tax_rate`, `tax_amount`, and `total_amount`.

#### 6. `Payment` (Permanent Transaction ID)
- `transaction_id`: Permanent unique identifier (`TXN-YYYYMMDD-XXXXXX`), generated strictly upon payment collection.
- Cannot be modified or deleted once created.
- `payment_method`: `cash`, `upi`, `card`, `credit` (Khata), `netbanking`.
- `amount`, `notes`, `created_at`.

#### 7. `CustomerLedger` & `CustomerPayment`
- Double-entry ledger recording every financial transaction impacting customer Khata balances.
- Check constraint: `CHECK (debit = 0 OR credit = 0)`.
- Enforces accurate `Customer.outstanding_amount` synchronization.

#### 8. `AuditLog`
- Immutable system audit trail.
- Captures `business`, `user`, `action`, `module`, `target_id`, `ip_address`, `user_agent`, `details` (JSON before/after state diff), and `timestamp`.

---

## 4. API Endpoints & Routing Architecture

### ViewSet Routers (Prefix `/api/`)
| Resource | ViewSet | Key Operations |
|---|---|---|
| `users` | `UserViewSet` | Staff provisioning, role assignment, lockout reset |
| `categories` | `CategoryViewSet` | Product taxonomy and hierarchical organization |
| `suppliers` | `SupplierViewSet` | Vendor profiles, contact details, payment terms |
| `products` | `ProductViewSet` | Inventory catalog, barcodes, price updates, reorder flags |
| `product-batches` | `ProductBatchViewSet` | Batch and expiration tracking per SKU |
| `customers` | `CustomerViewSet` | Customer profiles, Khata balance, credit limits |
| `purchases` | `PurchaseViewSet` | Inbound purchase orders, stock receipt, debit notes |
| `invoices` | `InvoiceViewSet` | Checkout, voiding, A4/thermal PDF, payment recording |
| `inventory` | `InventoryViewSet` | Manual stock adjustments, stock movement audit trail |
| `settings` | `SettingViewSet` | Store profile, receipt headers, tax parameters |
| `expenses` | `ExpenseViewSet` | Operating overhead logging, categorized settlements |
| `sales-returns` | `SalesReturnViewSet` | Customer returns, item restocking, credit notes |
| `purchase-returns`| `PurchaseReturnViewSet`| Supplier returns, debit notes, payable deductions |
| `customer-payments`| `CustomerPaymentViewSet`| Khata debt collections with permanent `TXN-` IDs |
| `supplier-payments`| `SupplierPaymentViewSet`| Vendor bill disbursements and voucher generation |
| `audit-logs` | `AuditLogViewSet` | Read-only compliance audit trail explorer |
| `communication-logs`| `CommunicationLogViewSet`| WhatsApp / SMS message dispatch history |

### Specialized API Action Endpoints
- **Authentication**:
  - `POST /api/auth/register/`: Tenant registration & OTP initiation
  - `POST /api/auth/verify-otp/`: OTP verification & account activation
  - `POST /api/auth/login/`: SimpleJWT token issuance
  - `POST /api/auth/refresh/`: JWT access token refresh
  - `GET /api/auth/me/`: Current authenticated user & store profile
- **Point-of-Sale & Invoicing**:
  - `GET /api/dashboard/?period={today|yesterday|7days|this_month|last_month}`: Aggregated store KPIs
  - `GET /api/invoices/<id>/pdf/`: High-fidelity ReportLab PDF binary stream
  - `POST /api/invoices/<id>/cancel/`: Secure invoice cancellation with reason capture
  - `POST /api/invoices/<id>/refund/`: Item-level sales return & refund processing
  - `GET /api/public/bill/<token>/`: Unauthenticated public digital receipt JSON
  - `GET /api/public/bill/<token>/document/`: Customer PDF download endpoint
  - `GET /s/<code>/`: Canonical short link resolver redirecting to digital bill
- **Inventory & Barcodes**:
  - `GET /api/products/<id>/barcode-label/`: Sticker sheet / roll printable label data
  - `POST /api/inventory/adjust/`: Single-item atomic stock adjustment
  - `POST /api/inventory/bulk-adjust/`: Multi-item batch reconciliation
  - `POST /api/inventory/import/`: Excel/CSV bulk product & stock import
  - `GET /api/inventory/import-template/`: Download standard Excel import template
- **Payments & Gateway**:
  - `POST /api/payments/razorpay/create-order/`: Dynamic UPI / gateway order creation
  - `POST /api/payments/razorpay/verify/`: Payment signature verification
  - `POST /api/payments/razorpay/webhook/`: Asynchronous payment capture webhook
  - `GET /api/payments/razorpay/reconciliation/`: Gateway fee & settlement audit
- **Statutory Reporting**:
  - `GET /api/reports/sales/`: Sales volume and gross profit reports
  - `GET /api/reports/gst/`: GSTR-1 compliant B2B, B2C, and HSN tax statements
  - `GET /api/reports/customers/`: Customer aging credit (Udhaar) ledger report
  - `GET /api/reports/reconciliation/`: Payment gateway reconciliation statement

---

## 5. Concurrency Control & Atomic Transactions

During peak store checkout hours, multiple cashier counters scan the same inventory items concurrently. The system prevents stock overselling through database-level row locking:

```python
# Concurrency Lock Pattern in invoice_service.py
from django.db import transaction

with transaction.atomic():
    # 1. Lock candidate product rows with select_for_update()
    locked_products = {
        p.id: p for p in Product.objects.select_for_update().filter(id__in=product_ids)
    }
    
    # 2. Validate current stock against requested quantity
    for item in items_data:
        prod = locked_products[item['product_id']]
        if prod.current_stock < item['quantity']:
            raise ValidationError(f"Insufficient stock for {prod.name}. Available: {prod.current_stock}")
        prod.current_stock -= item['quantity']
        prod.save(update_fields=['current_stock'])
    
    # 3. Create invoice, items, and inventory movement records atomically
    invoice = Invoice.objects.create(...)
```

---

## 6. Integrations & External Services

1. **Razorpay Payments**:
   - Dynamic UPI QR generation for cashier counters.
   - Secure server-side signature verification using `HMAC-SHA256`.
   - Webhook handler updating payment states asynchronously.
2. **Twilio WhatsApp & SMS**:
   - Automated dispatch of invoice links and payment receipts.
   - Automated Khata payment reminders with live balance figures.
   - Comprehensive error trapping with status logged in `CommunicationLog`.
3. **ReportLab Document Engine**:
   - Vector-quality A4 tax invoices with statutory GST tables and bank details.
   - High-density thermal receipt generation formatted for standard 80mm (48-column) and 58mm (32-column) ESC/POS printers.
   - In-memory PDF streaming (`io.BytesIO`) without temporary disk write overhead.
4. **Supabase Cloud Object Storage**:
   - S3-compatible cloud storage adapter (`api/supabase_storage.py`).
   - Automatically archives generated PDF bills and store logo assets.
   - Seamless transparent fallback to local disk storage if cloud credentials are not provisioned.
