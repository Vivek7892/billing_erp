# Design System, UI/UX Standards & Component Guidelines

**Applications Covered**:  
1. Store POS & Merchant Management SPA (`frontend/`)  
2. Central Company Admin Dashboard (`admin-frontend/`)  
3. Public Customer Digital Bill Viewer (`/bill/<token>`)  

---

## 1. Design Philosophy & Guiding Principles

The **DreamWithTech Billing ERP** design system is crafted for high-pressure retail store checkouts and rigorous corporate accounting environments:

1. **High Information Density**: Compact vertical spacing and restrained padding allow cashiers and accountants to review complex tables without excessive scrolling.
2. **Cognitive Clarity**: Colors are strictly reserved for semantic meaning (overdue credit, stockouts, success states). Non-essential decorative gradients or playful animations are prohibited.
3. **Tabular Alignment**: Every financial amount, stock count, barcode, invoice number, and timestamp is displayed using monospaced tabular numerals (`tabular-nums`) for rapid vertical scanning.
4. **Ergonomic Contrast**: Crisp borders (`#D7DEE7` / `#E2E8F0`) and sharp ink text (`#172033` / `#0F172A`) ensure clear legibility under bright fluorescent store lighting and on diverse POS monitor hardware.
5. **Universal Navigation Consistency**: Simple text-format Back buttons on all pages with consistent navigation flow across desktop and mobile screens.

---

## 2. Color Palettes & Design Tokens

### Application 1: Store POS & Merchant Portal (`frontend/`)

Built with **Tailwind CSS v4** utilizing an ergonomic Navy, Slate, and Teal palette:

```
+-----------------------------------------------------------------------------------+
|  PRIMARY NAVY       |  SECONDARY SLATE   |  ACCENT TEAL      |  INK (MAIN TEXT)   |
|  #1E3A5F            |  #475569           |  #0F766E          |  #172033           |
+---------------------+--------------------+-------------------+--------------------+
|  PAGE BACKGROUND    |  CARD SURFACE      |  BORDER LINE      |  MUTED TEXT        |
|  #F8FAFC            |  #FFFFFF           |  #D7DEE7          |  #64748B           |
+-----------------------------------------------------------------------------------+
```

#### Core Tokens
| Token Name | Hex Code | Tailwind / CSS Class | Purpose & Usage |
|---|---|---|---|
| **Primary Navy** | `#1E3A5F` | `bg-[#1E3A5F]`, `text-[#1E3A5F]` | Primary actions, main navigation active states, brand headers |
| **Primary Hover** | `#162F4D` | `hover:bg-[#162F4D]` | Hover state for primary buttons |
| **Secondary Slate** | `#475569` | `text-[#475569]` | Secondary labels, neutral icons, subtle borders |
| **Accent Teal** | `#0F766E` | `text-[#0F766E]` | Procurement indicators, margin metrics, growth trends |
| **Main Text (Ink)** | `#172033` | `text-[#172033]` | Primary headings, table text, customer names |
| **Secondary Text** | `#64748B` | `text-[#64748B]` | Descriptions, phone numbers, table subtitles |
| **Muted Text** | `#94A3B8` | `text-[#94A3B8]` | Table headers, metadata timestamps, field labels |
| **Border Line** | `#D7DEE7` | `border-[#D7DEE7]` | Card borders, table dividers, input borders |
| **Page Background** | `#F8FAFC` | `bg-[#F8FAFC]` | Application canvas background |
| **Surface White** | `#FFFFFF` | `bg-[#FFFFFF]` | Cards, modals, topbar, table row backgrounds |

#### Semantic Intent Colors
| Semantic Intent | Hex Code | Light Mode Class | Meaning & Trigger |
|---|---|---|---|
| **Success / Paid** | `#15803D` | `text-[#15803D]`, `bg-[#DCFCE7]` | Paid invoices, in-stock inventory, positive margins |
| **Warning / Low Stock** | `#B45309` | `text-[#B45309]`, `bg-[#FEF3C7]` | Low-stock alert, pending invoices, partial payments |
| **Error / Void / Danger** | `#B91C1C` | `text-[#B91C1C]`, `bg-[#FEE2E2]` | Out-of-stock items, voided bills, cancelled orders |
| **Info / Links** | `#2563EB` | `text-[#2563EB]`, `bg-[#DBEAFE]` | Active links, information tooltips, short links |
| **Refund / Credit Note** | `#C2410C` | `text-[#C2410C]`, `bg-[#FFEDD5]` | Sales returns, vendor debit notes, payment reversals |

---

### Application 2: Central Company Admin Dashboard (`admin-frontend/`)

Built with **Pure CSS Modules & Custom Properties** (Strictly No Tailwind CSS) utilizing an enterprise Blue, Navy-Slate, and Cyan palette:

```
+-----------------------------------------------------------------------------------+
|  PRIMARY BLUE       |  PRIMARY DARK      |  ACCENT CYAN      |  NAVY SLIDEBAR     |
|  #0057B8            |  #003F8F           |  #16A9D8          |  #0F172A           |
+---------------------+--------------------+-------------------+--------------------+
|  PAGE BACKGROUND    |  CARD SURFACE      |  BORDER LINE      |  MAIN TEXT         |
|  #F8FAFC            |  #FFFFFF           |  #E2E8F0          |  #0F172A           |
+-----------------------------------------------------------------------------------+
```

#### CSS Custom Variables (`admin-frontend/src/styles/variables.css`)
```css
:root {
  --primary: #0057B8;
  --primary-hover: #004494;
  --primary-dark: #003F8F;
  --primary-subtle: #EBF3FC;
  --accent: #16A9D8;
  --sidebar-bg: #0F172A;
  --sidebar-text: #94A3B8;
  --sidebar-active: #FFFFFF;
  --bg-page: #F8FAFC;
  --bg-surface: #FFFFFF;
  --bg-subtle: #F1F5F9;
  --border: #E2E8F0;
  --border-subtle: #F1F5F9;
  --text-main: #0F172A;
  --text-secondary: #475569;
  --text-muted: #94A3B8;
  --success: #16A34A;
  --warning: #D97706;
  --danger: #DC2626;
  --radius-sm: 4px;
  --radius-md: 6px;
  --radius-lg: 8px;
}
```

---

## 3. Typography & Tabular Numerals

### Font Families
- **Interface UI Font**: Inter, system sans-serif (`-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif`).
- **Tabular Numeric & Barcode Font**: JetBrains Mono, monospace (`ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace`).

### Strict Formatting Standards (`utils/formatters.js`)
All numeric figures across tables, dashboards, cards, receipts, and reports must be formatted using Indian locale rules:

```javascript
// Centralized Formatters Reference
formatCurrency(125000)     // => "₹1,25,000.00"
formatCurrency(0)          // => "₹0.00"
formatNumber(125000)       // => "1,25,000"
formatNumber(1250.5, 3)    // => "1,250.500" (Quantities)
formatPercent(18)          // => "18.00%"
formatDate("2026-11-02")   // => "02 Nov 2026"
formatDateTime(isoDate)    // => "02 Nov 2026, 02:45 PM"
```

**Rule**: All `<td className="font-mono tabular-nums text-right">` tags must right-align numbers for rapid column sum verification.

---

## 4. Key UI Patterns & Component Guidelines

### 1. Simple Text-Format Back Button
- Displayed at the top of detail and form pages (both mobile and desktop).
- Styled as a clean text button with a left arrow icon (`ArrowLeft`).
- Preserves natural browser/router navigation history (`navigate(-1)` or fallback to parent index).

### 2. Layout Topbar Identifiers
- **7-Character Unique Shop ID**: Displayed prominently in a monospace pill badge (e.g., `DWKT2618`) with 1-click copy-to-clipboard functionality.
- **Statutory GSTIN**: Displayed alongside the Shop ID if registered (e.g., `GSTIN: 29AABCU9603R1ZM`). If unregistered or composition, omitted or labeled accordingly.

### 3. Dashboard Period Filter Button
- Compact, symbol-only icon button (`Filter` or `Calendar`) opening a clean dropdown menu.
- Supports instant period switching: `Today`, `Yesterday`, `Last 7 Days`, `This Month`, `Last Month`.

### 4. Cashier Checkout Screen (POS New Bill)
- Full viewport height layout (`h-screen overflow-hidden`).
- Left column (60%): Fast item search, category quick-pick chips, and live cart table.
- Right column (40%): Customer Khata selector, subtotal/tax/discount summary, cash tender keypad, and large primary action button (`F8 Complete Bill`).

---

## 5. Print & Document Templates Design

### 1. Thermal Receipts (80mm & 58mm ESC/POS)
- Width: Fixed 80mm (48 characters/line) or 58mm (32 characters/line).
- Font: Monospaced uppercase text, bold headers, and crisp dotted dividing lines.
- Elements: Store Name, GSTIN, Shop ID, Invoice Number, Date/Time, Itemized Qty x Rate Table, Taxable & GST Breakup, Tender Type, and QR Code.

### 2. Barcode Sticker Labels
- Roll Format: 50mm x 25mm or 38mm x 25mm single stickers.
- Sheet Format: Standard A4 sticker sheets (24 labels: 3x8 grid; 32 labels: 4x8 grid).
- Elements: Store Name (Header), Product Name, Selling Price in prominent INR, Code128 Barcode graphic, and SKU string.
