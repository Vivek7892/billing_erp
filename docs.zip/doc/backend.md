# Backend Architecture & Technical Reference

## 1. System Overview & Technology Stack

The **Billing ERP** backend is an enterprise-grade RESTful API built on **Django 4.2** and **Django REST Framework (DRF)**. It is architected for retail stores, supermarkets, wholesalers, and multi-counter POS deployments requiring high-concurrency transaction processing, strict financial ledger integrity, GST compliance, real-time inventory reconciliation, and multi-tenant business isolation.

### Key Technology Stack

- **Framework**: Django 4.2.16, Django REST Framework 3.15+
- **Authentication**: JWT (`djangorestframework-simplejwt`), Session/Bearer hybrid, SHA-256 OTP verification
- **Database Engine**: PostgreSQL (Production) / SQLite3 (Development), configured via `dj-database-url`
- **Asynchronous & HTTP Client**: `httpx` for third-party integrations (Twilio, Razorpay, Supabase)
- **Document Engine**: ReportLab 4.x, Pillow, `qrcode[pil]`, `python-barcode`
- **Spreadsheet Engine**: `openpyxl` (bulk inventory import/export and sales reports)
- **Cloud Object Storage**: Supabase Storage / Local media fallback
- **Payments & Telephony**: Razorpay SDK (`razorpay`), Twilio SDK (`twilio>=8.0.0`)
- **WSGI / Production Server**: Gunicorn + WhiteNoise (Brotli compression)

---

## 2. Directory Structure & Architectural Blueprint

```
backend/
├── api/
│   ├── management/commands/     # Custom Django management commands (e.g., seeding, cron jobs)
│   ├── migrations/              # Database schema migration histories
│   ├── services/                # Encapsulated domain business services
│   │   ├── invoice_service.py   # Invoice creation, calculation, numbering, and inventory lock
│   │   └── notification_service.py # Automated alert generation & event deduplication
│   ├── calculations.py          # Pure functional financial and tax calculation engine
│   ├── models.py                # Normalized relational domain models & check constraints
│   ├── pagination.py            # Custom limit-offset & page-number paginators
│   ├── pdf_utils.py             # ReportLab PDF document layout engine (A4 & Thermal 80mm/58mm)
│   ├── permissions.py           # Role-based access control (RBAC) authorization policies
│   ├── serializers.py           # ModelSerializers, nested serializers, input validators
│   ├── supabase_storage.py      # Cloud storage adapter for receipt archiving and brand logos
│   ├── urls.py                  # API routing table, ViewSet routers, custom action endpoints
│   ├── utils.py                 # Cryptographic helpers, IP resolvers, short code generators
│   └── views.py                 # ViewSets, APIViews, report aggregators, webhooks
├── core/
│   ├── settings.py              # Environment configuration, database routing, JWT settings
│   ├── urls.py                  # Root URL configuration, media routing, short link redirector
│   └── wsgi.py                  # Production WSGI application hook
├── requirements.txt             # Python package dependencies
└── manage.py                    # Django management CLI
```

---

## 3. Data Models & Relational Architecture

The relational schema is enforced with database-level `CheckConstraint` rules to guarantee zero negative monetary balances, non-negative stock counts, and valid tax ranges.

### Core Domain Models

```mermaid
erDiagram
    Business ||--o{ User : employs
    Business ||--o{ Product : owns
    Business ||--o{ Customer : registers
    Business ||--o{ Supplier : contracts
    Business ||--o{ Purchase : executes
    Business ||--o{ Invoice : issues
    Business ||--o{ Expense : logs
    Business ||--o{ Notification : generates

    Customer ||--o{ CustomerLedger : records
    Customer ||--o{ CustomerPayment : makes
    Customer ||--o{ Invoice : billed_to

    Supplier ||--o{ SupplierLedger : records
    Supplier ||--o{ SupplierPayment : receives
    Supplier ||--o{ Purchase : fulfills

    Purchase ||--|{ PurchaseItem : contains
    Invoice ||--|{ InvoiceItem : contains
    Invoice ||--o{ Payment : receives
    Invoice ||--o{ SalesReturn : returns
    Invoice ||--o{ RazorpayTransaction : gateway

    Product ||--o{ InvoiceItem : references
    Product ||--o{ PurchaseItem : references
    Product ||--o{ InventoryTransaction : tracks
```

### Detailed Schema Breakdown

#### 1. `Business` & Multi-Tenant Scoping

Every major record (`Product`, `Customer`, `Invoice`, `Purchase`, `Ledger`) is scoped to a `Business` foreign key.

- `id`: UUID primary key.
- `name`, `business_type`, `owner_name`, `mobile`, `email`, `address`.
- `gstin`, `pan`: Statutory tax identifiers.
- `invoice_prefix`: Configurable prefix (default: `"INV"`).
- `invoice_start_number`: Sequential invoice starting integer (default: `1001`).
- `currency`: Default currency symbol (`"₹"`).
- `tax_enabled`: Global GST switch flag.

#### 2. `User` & Role-Based Access Control (RBAC)

Inherits `AbstractUser` and supports 5 discrete roles:

- `owner`: Unrestricted system access across all stores, configurations, and financial ledgers.
- `admin`: Store management, user provisioning, stock adjustments, financial reporting.
- `manager`: Inventory procurement, customer credit approvals, price editing, returns.
- `cashier`: POS billing, receipt printing, customer walk-in registration, cash drawer ops.
- `accountant`: Ledger auditing, expense reconciliation, tax reporting, credit recovery.

#### 3. `Product` & Catalog Controls

- `sku` (Unique per business), `barcode` (UPC/EAN/Code128).
- `mrp`, `purchase_price`, `selling_price`: Decimal(10, 2).
- `current_stock`, `minimum_stock`: Real-time stock levels with low-stock alerts.
- `gst_percent`: Configurable GST slab (0%, 5%, 12%, 18%, 28%).
- Database Constraints:
  - `product_mrp_nonnegative`: `mrp >= 0`
  - `product_purchase_price_nonnegative`: `purchase_price >= 0`
  - `product_selling_price_nonnegative`: `selling_price >= 0`
  - `product_gst_valid`: `0 <= gst_percent <= 100`

#### 4. `Invoice` & `InvoiceItem`

Represents an executed or drafted retail/wholesale tax invoice.

- `status`: `draft`, `confirmed`, `posted`, `completed`, `cancelled`, `partially_refunded`, `refunded`.
- `payment_status`: `pending`, `paid`, `failed`, `partial`, `credit`, `refunded`.
- `subtotal`, `discount_amount`, `tax_amount`, `round_off`, `grand_total`, `paid_amount`, `balance_due`.
- `public_token`: 32-byte cryptographically secure random token for public digital invoice access (`/bill/<token>`).
- Constraints: All monetary fields are bounded to non-negative values via DB constraints.

#### 5. `CustomerLedger` & `SupplierLedger`

Maintains double-entry transactional ledgers:

- `entry_type`:
  - Customer: `invoice` (debit), `payment` (credit), `sales_return` (credit), `adjustment`.
  - Supplier: `purchase` (credit), `payment` (debit), `purchase_return` (debit), `adjustment`.
- `debit`, `credit`: Decimal values enforced by constraint `debit == 0 OR credit == 0` (strictly one-sided ledger entries).
- `event_key`: Unique idempotency key preventing duplicate postings during retries.

#### 6. `RazorpayTransaction`

Maintains full webhook and order lifecycle states:

- `razorpay_order_id`, `razorpay_payment_id`, `razorpay_signature`.
- `amount`, `status` (`created`, `initiated`, `pending`, `success`, `failed`, `expired`).
- `provider_reference`, `failure_reason`, `response_data`.

#### 7. `AuditLog`

Immutable security and compliance log tracking every CRUD and sensitive business operation:

- `user`, `business`, `action`, `module`, `entity`, `entity_id`, `entity_name`.
- `previous_value`, `new_value`: JSON serialized before-and-after snapshots.
- `reason`, `ip_address`, `user_agent`, `result`, `failure_reason`.

#### 8. `Notification`

Event-driven in-app alerts with automated deduplication:

- `notification_type`: `low_stock`, `invoice_overdue`, `payment_received`, `approval_required`, etc.
- `severity`: `info`, `warning`, `danger`, `success`.
- `dedup_key`: Hash string preventing redundant spam alerts for recurring conditions.

#### 9. `CommunicationLog`

Outbound messaging records for customer bills, payment reminders, and statements:

- `channel`: `whatsapp`, `sms`, `email`.
- `message_type`: `invoice`, `payment_reminder`, `statement`, `purchase_confirmation`.
- `status`: `sent`, `delivered`, `failed`.
- `error_message`, `sent_at`, `sent_by`.

---

## 4. Business Calculation Engine (`calculations.py`)

Financial math is centralized to prevent rounding errors and discrepancies across POS, invoices, and reports:

### Mathematical Rules

1. **Line Item Subtotal**:
   $$\text{Base Amount} = \text{Quantity} \times \text{Unit Price}$$
2. **Item Discount**:
   $$\text{Item Discount} = \frac{\text{Base Amount} \times \text{Discount \%}}{100}$$
3. **GST Calculation (CGST & SGST Split)**:
   $$\text{Taxable Value} = \text{Base Amount} - \text{Item Discount}$$
   $$\text{GST Amount} = \frac{\text{Taxable Value} \times \text{GST \%}}{100}$$
   $$\text{CGST} = \frac{\text{GST Amount}}{2}, \quad \text{SGST} = \frac{\text{GST Amount}}{2}$$
   _(Or IGST = 100% of GST Amount for inter-state transactions based on `place_of_supply`)_.
4. **Invoice Round-Off**:
   $$\text{Unrounded Total} = \sum \text{Item Totals} - \text{Bill Discount}$$
   $$\text{Grand Total} = \text{round}(\text{Unrounded Total})$$
   $$\text{Round Off} = \text{Grand Total} - \text{Unrounded Total}$$

---

## 5. Ledger & Accounting Workflows

### Customer Credit & Settlement Flow

```mermaid
sequenceDiagram
    autonumber
    actor Cashier
    participant POS as Frontend POS
    participant API as Django API
    participant DB as Database
    participant Ledger as Customer Ledger

    Cashier->>POS: Tender bill with payment_method="credit"
    POS->>API: POST /api/invoices/
    API->>DB: Validate Customer Credit Limit
    alt Outstanding + Bill Amount > Credit Limit
        API-->>POS: 400 Bad Request: Credit limit exceeded
    else Allowed
        API->>DB: Save Invoice (balance_due = grand_total)
        API->>Ledger: Insert CustomerLedger (debit=grand_total, entry_type='invoice')
        API->>DB: Update Customer outstanding_amount += grand_total
        API-->>POS: 201 Created (Invoice confirmed)
    end

    Note over Cashier,Ledger: Customer returns later to settle dues
    Cashier->>POS: Record Payment
    POS->>API: POST /api/customer-payments/
    API->>DB: Save CustomerPayment record
    API->>Ledger: Insert CustomerLedger (credit=amount, entry_type='payment')
    API->>DB: Update Customer outstanding_amount -= amount
    API-->>POS: 200 OK (Payment Recorded)
```

---

## 6. Inventory Movement & Lifecycle Management

Stock updates are strictly audited through `InventoryTransaction` records. Direct updates to `product.current_stock` without movement logs are prevented.

### Movement Triggers

1. **Sales Invoice Completed**: Stock deducted with `transaction_type='sale'`.
2. **Sales Return Approved**: Stock returned with `transaction_type='returned'`.
3. **Purchase PO Received**: Stock incremented with `transaction_type='purchase'`.
4. **Purchase Return**: Stock deducted with `transaction_type='stock_out'`.
5. **Physical Audit / Damage**:
   - `POST /api/inventory/adjust/`: Increments or decrements with mandatory justification `reason`.
   - `POST /api/inventory/bulk-adjust/`: Batch reconciliation across multiple SKUs.
   - `POST /api/inventory/import/`: Multi-row Excel/CSV file upload matching by SKU.

---

## 7. Payments & Gateway Integrations

### 1. Offline POS Tenders

- **Cash**: Direct recording with cash tender calculation (change given) logged on client.
- **Card / UPI QR**: Standalone machine/counter terminal reference logging.
- **Credit**: Deferred settlement booked directly to `CustomerLedger`.

### 2. Online Razorpay Integration

1. **Order Creation** (`POST /api/payments/razorpay/create-order/`):
   - Invokes `razorpay.Client.order.create()`.
   - Generates and persists `RazorpayTransaction` in `created` status.
2. **Client Checkout**:
   - Opens Razorpay Standard Checkout modal using dynamic order token.
3. **Payment Verification** (`POST /api/payments/razorpay/verify/`):
   - Cryptographically verifies signature using HMAC-SHA256 (`razorpay_order_id|razorpay_payment_id` against `RAZORPAY_KEY_SECRET`).
   - Marks invoice as `paid`, updates transaction status to `success`, records payment.
4. **Webhook Processing** (`POST /api/payments/razorpay/webhook/`):
   - Idempotently captures asynchronous gateway events (`payment.captured`, `payment.failed`, `refund.created`).
5. **Reconciliation Engine** (`GET /api/payments/razorpay/reconciliation/`):
   - Audits discrepancies between local invoice payments and Razorpay settlement balances.

---

## 8. PDF Generation & Document Printing (`pdf_utils.py`)

The backend contains a specialized document generation pipeline using **ReportLab**:

### Document Layouts

1. **Standard Tax Invoice (A4 Format)**:
   - Corporate header with business branding, GSTIN, PAN, and contact credentials.
   - Dual-party billing blocks (Billed By vs Billed To) with Place of Supply.
   - Itemized tabular grid: S.No, Item Description, HSN Code, Quantity, Rate, Discount, GST %, Tax Amount, Total.
   - Statutory tax split summary (CGST, SGST, IGST breakdown table).
   - Bank settlement credentials (Account Number, IFSC, UPI ID) and dynamic payment QR code.
   - Authorized signatory box and terms & conditions footer.
2. **Thermal POS Receipt (80mm & 58mm)**:
   - Compact ESC/POS-optimized formatting with high-contrast monochrome layout.
   - Condensed item list, savings summary, cashier ID, and receipt verification barcode.
3. **Product Barcode Labels**:
   - Dynamically renders Code128 barcodes with store name, product title, SKU, and MRP for thermal label printers.

---

## 9. Comprehensive API Endpoint Reference

| HTTP Method | Endpoint                                  | Description                                                   | Auth Required    |
| ----------- | ----------------------------------------- | ------------------------------------------------------------- | ---------------- |
| `POST`      | `/api/auth/login/`                        | Authenticate user & return JWT tokens                         | No               |
| `POST`      | `/api/auth/refresh/`                      | Refresh expired access token                                  | No               |
| `GET`       | `/api/auth/me/`                           | Get current user profile and role permissions                 | Yes              |
| `POST`      | `/api/me/change-password/`                | Change password for current user                              | Yes              |
| `GET`       | `/api/dashboard/`                         | Real-time analytics, KPIs, sales charts, watchlist            | Yes              |
| `GET`       | `/api/search/`                            | Global Ctrl+K omnisearch across invoices, products, customers | Yes              |
| `GET`       | `/api/products/`                          | Paginated product list with search, category, stock filter    | Yes              |
| `POST`      | `/api/products/`                          | Create new catalog item                                       | Admin/Manager    |
| `GET`       | `/api/products/{id}/barcode-label/`       | Generate printable barcode sticker                            | Yes              |
| `GET`       | `/api/invoices/`                          | List invoices with date, payment, and status filters          | Yes              |
| `POST`      | `/api/invoices/`                          | Create and execute invoice, locking stock and ledger          | Yes              |
| `GET`       | `/api/invoices/{id}/pdf/`                 | Stream generated ReportLab A4/Thermal PDF                     | Yes              |
| `POST`      | `/api/invoices/{id}/cancel/`              | Void invoice, reverse stock, and audit reason                 | Admin/Manager    |
| `POST`      | `/api/invoices/{id}/refund/`              | Issue full/partial refund and credit note                     | Admin/Manager    |
| `GET`       | `/api/public/bill/{token}/`               | Unauthenticated public invoice detail endpoint                | No               |
| `POST`      | `/api/inventory/adjust/`                  | Single-product stock balance correction                       | Admin/Manager    |
| `POST`      | `/api/inventory/bulk-adjust/`             | Multi-product batch stock reconciliation                      | Admin/Manager    |
| `POST`      | `/api/inventory/import/`                  | CSV/Excel inventory batch import                              | Admin/Manager    |
| `GET`       | `/api/customers/`                         | Customer directory with outstanding balances                  | Yes              |
| `POST`      | `/api/customer-payments/`                 | Record customer credit ledger payment                         | Yes              |
| `GET`       | `/api/suppliers/`                         | Supplier directory and procurement ledger                     | Yes              |
| `POST`      | `/api/supplier-payments/`                 | Record vendor payment disbursement                            | Yes              |
| `GET`       | `/api/purchases/`                         | Procurement order history                                     | Yes              |
| `POST`      | `/api/purchases/`                         | Book purchase order, incrementing inventory                   | Admin/Manager    |
| `GET`       | `/api/reports/sales/`                     | Sales volume, tax, and revenue breakdown                      | Admin/Accountant |
| `GET`       | `/api/reports/profit/`                    | Gross & net margin analytics per SKU                          | Admin/Accountant |
| `GET`       | `/api/reports/gst/`                       | GSTR-1 compliant tax filing ledger                            | Admin/Accountant |
| `GET`       | `/api/audit-logs/`                        | Security and compliance audit trail                           | Admin            |
| `GET`       | `/api/recycle-bin/`                       | View soft-deleted records across entities                     | Admin            |
| `POST`      | `/api/recycle-bin/{entity}/{id}/restore/` | Restore soft-deleted entity                                   | Admin            |
| `GET`       | `/api/notifications/`                     | Real-time system notifications and alerts                     | Yes              |
| `POST`      | `/api/invoices/{id}/send-whatsapp/`       | Dispatch digital bill via WhatsApp (Twilio)                   | Yes              |

---

## 10. Verification & Automated Testing

The backend includes a comprehensive test suite covering business rules, accounting constraints, public bills, and audit operations:

- `backend/api/tests.py`: Endpoint regression suite.
- `backend/api/test_business_rules.py`: Edge cases for GST math, negative stock prevention, and credit limits.
- `backend/api/test_audit_and_recycle_bin.py`: Audit trail validation and soft-deletion restoration.
- `backend/api/test_communication_actions.py`: WhatsApp/SMS dispatch mocks.
- `backend/api/test_public_bill.py`: Public bill token verification and security boundaries.

### Running Test Suite

```bash
cd backend
python manage.py test api
```
