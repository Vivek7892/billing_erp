# Product Requirements Document (PRD)

**Product Name**: DreamWithTech Billing ERP  
**Product Type**: Cloud Point-of-Sale (POS), Retail ERP, Inventory Control & SaaS Platform  
**Target Domains**:  
- Store POS & Merchant Portal: `https://app.dreamwithtech.dev/`  
- Central Company Admin Dashboard: `https://admin.dreamwithtech.dev/`  
- Customer Digital Receipt Portal: `https://app.dreamwithtech.dev/bill/<token>`  
- Canonical Short Link Service: `https://app.dreamwithtech.dev/s/<code>/`  
**Current Version**: 2.4.0 (Enterprise Multi-Tenant Release)  
**Last Updated**: November 2026  

---

## 1. Executive Summary & Vision

DreamWithTech Billing ERP is an enterprise-grade cloud Point-of-Sale (POS) and Retail Enterprise Resource Planning (ERP) platform architected for grocery stores, supermarkets, pharmacies, retail outlets, and wholesale distribution businesses across India.

Traditional desktop billing systems suffer from severe limitations: sluggish checkout counters, fragile local databases vulnerable to disk crashes, paper-based Khata credit books, manual GST calculation errors, and lack of customer digital engagement. 

DreamWithTech Billing ERP bridges this gap by providing:
1. **Zero-Latency Checkout**: Sub-15 second cashier checkout powered by an ergonomic, keyboard-driven interface (`F1`-`F8`), automatic barcode focus, and cash tender denomination calculators.
2. **Strict Financial Integrity**: 100% double-entry bookkeeping across customer credit (Khata) and supplier debit ledgers, backed by database-level check constraints.
3. **Statutory GST Compliance**: Automated CGST, SGST, and IGST tax splits, mandatory HSN code tracking, and GSTR-1 compliant B2B/B2C output schedules.
4. **Omnichannel Digital Experience**: Automated digital receipt dispatch via WhatsApp and SMS, dynamic UPI payment QR generation, and real-time payment reconciliation.
5. **Multi-Tenant SaaS Architecture**: Complete tenant isolation for thousands of retail stores, each assigned an immutable **7-character unique Shop ID** (`DWAAYYNN`), monitored via a central Company Admin Dashboard.

---

## 2. Target Users & Personas

| Persona | Role | Primary Goals & Workflows |
|---|---|---|
| **Store Owner** | Executive / Super Admin | Monitor real-time gross/net margins, track daily revenue trends, review credit dues, manage store settings, and oversee staff accounts. |
| **Store Manager** | Operations & Procurement | Manage master product catalogs, execute supplier purchase orders, reconcile stock adjustments, print barcode labels, and authorize discounts/refunds. |
| **Cashier / POS Operator** | Billing & Checkout | Scan barcodes rapidly, park and resume held bills, accept cash/UPI/credit payments, and print thermal receipts (80mm/58mm) or share bills on WhatsApp. |
| **Accountant** | Finance & Tax Compliance | Reconcile payment gateway transactions against bank deposits, audit customer/vendor ledgers, review operating expenses, and export statutory GSTR-1 summaries. |
| **Retail Customer** | End Customer | View high-fidelity digital receipts on mobile devices via secure 24-byte tokenized links, review itemized GST splits, and make instant UPI payments. |
| **Platform Super Admin** | SaaS Company Admin | Manage merchant stores, configure subscription pricing tiers, monitor Monthly Recurring Revenue (MRR), audit platform logs, and handle technical support. |

---

## 3. Core Business Objectives & Success Metrics

- **Checkout Speed**: Average transaction completion time under **15 seconds** for carts containing 5 to 10 items.
- **Data Integrity**: **0% discrepancy** between invoice tender totals and ledger entries via atomic transactions.
- **Inventory Precision**: Real-time atomic inventory deduction (`select_for_update()`) preventing multi-counter overselling.
- **Statutory Audit Readiness**: Automated GSTR-1 schedule generation matching Indian GST portal upload formats.
- **Khata Collection Rate**: Reduce overdue receivables by **25%** through automated WhatsApp payment reminders and digital statements.
- **SaaS Platform Scale**: Support multi-counter concurrent billing across 1,000+ isolated merchant tenants with zero cross-tenant data leakage.

---

## 4. Multi-Tenant Architecture & Domain Separation

The DreamWithTech platform operates across distinct architectural domains:

```
+----------------------------------------------------------------------------------------------------+
|                                    DREAMWITHTECH PLATFORM ECOSYSTEM                                |
+----------------------------------------------------------------------------------------------------+
|                                                                                                    |
|   1. MERCHANT POS & STORE ERP (Port 5173)              2. COMPANY ADMIN DASHBOARD (Port 5174)      |
|   https://app.dreamwithtech.dev/                       https://admin.dreamwithtech.dev/             |
|   - Cashier POS Checkout & Barcodes                    - Platform MRR / ARR Analytics              |
|   - Store Inventory, Catalog & Batches                 - Merchant Store Directory & Provisioning   |
|   - Customer Khata & Vendor Ledgers                    - Subscription Tiers & Mandate Management   |
|   - GST Reports & Expense Logging                      - Platform Ledger, Refunds & Disputes       |
|                                                        - Audit Trails, Helpdesk & RBAC             |
|                                                                                                    |
|   3. CUSTOMER DIGITAL BILL PORTAL                      4. RESTFUL API BACKEND (Port 8000)          |
|   https://app.dreamwithtech.dev/bill/<token>           https://api.dreamwithtech.dev/              |
|   - Mobile-optimized responsive bill viewer            - Django 4.2 REST Framework API             |
|   - Instant A4 / Thermal PDF download                  - SimpleJWT & OTP Authentication            |
|   - Dynamic UPI payment collection QR                  - PostgreSQL Database + WhiteNoise          |
|                                                                                                    |
+----------------------------------------------------------------------------------------------------+
```

### 7-Character Unique Shop ID Standard
Every merchant business is permanently assigned a unique 7-character Shop ID adhering to the standard:
$$\text{Format: } \mathbf{DWAAYYNN}$$
- `DW`: Fixed DreamWithTech prefix (2 characters).
- `AA`: Two randomly generated uppercase alphabetic characters (2 characters).
- `YY`: Last two digits of the registration year (e.g., `26` for 2026).
- `NN`: Two randomly generated digits (2 characters).

**Invariants**:
- Generated strictly on the backend during store provisioning.
- Database `UNIQUE` constraint and indexed for fast lookups.
- Immutable: cannot be manually modified even if the shop name changes.
- Retired ID Table (`RetiredShopID`): Deleted Shop IDs are permanently retired and never recycled.
- Displayed prominently in the top layout bar, store lists, and administrative dashboards with one-click copy functionality.

---

## 5. Comprehensive Module Inventory

### Store POS & Merchant Application (26 Integrated Modules)

#### Module 1: POS / New Bill (`/pos` / `/new-bill`)
- Ergonomic cashier billing interface designed for sub-second keyboard operation.
- Global keyboard shortcut bindings:
  - `F1`: Focus barcode search field
  - `F2`: Open Cash Tender / Payment modal
  - `F3`: Open Customer search / Khata selection
  - `F4`: Apply Bill-level Discount (% or flat ₹)
  - `F6`: Park current cart into Drafts
  - `F7`: Clear current cart
  - `F8`: Complete bill and trigger instant printing
- Live product lookup by barcode, SKU, or name with stock count and batch visibility.
- Tabular item grid with inline quantity modification, unit price display, and GST percentage breakdown.
- Cash tender denomination calculator with automatic change calculation.
- Dynamic UPI QR code modal for instant scan-and-pay collection.

#### Module 2: Executive Dashboard (`/` / `/dashboard`)
- High-contrast KPI cards: Today's Revenue, Net Profit, Total Bills Issued, and Overdue Customer Dues.
- Time-range filter: `today`, `yesterday`, `7days`, `this_month`, `last_month`.
- Recharts 7-Day Revenue & Profit trajectory area charts.
- Hourly Sales Heatmap revealing peak store checkout rush hours.
- Payment Tender Distribution donut chart (Cash, UPI, Card, Khata/Credit).
- Low-Stock and Out-of-Stock immediate watchlist.

#### Module 3: Invoice Directory & History (`/bills`)
- Historical sales invoices directory with multi-parameter filtering (date range, payment status, customer, tender type).
- Invoice status indicators: `Paid`, `Partial`, `Unpaid`, `Cancelled`, `Refunded`.
- Actions: Void / Cancel bill with mandatory reason capture, issue Sales Return credit notes, re-print thermal/A4 documents.
- Permanent Transaction ID tracking for each payment installment collected.

#### Module 4: Payment Reconciliation (`/reconciliation`)
- Compares captured Razorpay gateway transactions against local store payment records.
- Audits gateway fees, statutory 18% GST deductions on fees, and net bank settlement amounts.
- Discrepancy flagging for unmatched gateway reference IDs or chargeback requests.

#### Module 5: Drafts & Parked Bills (`/drafts`)
- One-key (`F6`) suspension of active checkout carts when a customer steps away or delays payment.
- Unpark / resume held carts instantly without loss of scanned line items.
- LocalStorage fallback cache ensuring cart survival across browser reloads or network drops.

#### Module 6: Sales Returns & Customer Refunds (`/returns`)
- Itemized sales return processing against original invoice numbers.
- Automatic inventory restocking toggle (restock vs damaged/write-off).
- Refund settlement options: Cash payout, bank transfer, or customer Khata balance credit note.

#### Module 7: Master Product Catalog (`/products`)
- Complete inventory master: Product Name, SKU, Barcode (UPC/EAN/Code128), Category, HSN Code.
- Multi-pricing model: Purchase Cost Price, Selling Price (tax-inclusive/exclusive), and Maximum Retail Price (MRP).
- Statutory GST slab assignment: `0%`, `5%`, `12%`, `18%`, `28%`.
- Unit definitions: Pieces (`pcs`), Kilograms (`kg`), Grams (`g`), Liters (`L`), Packets (`pkt`), Boxes (`box`).
- Minimum threshold alert levels for automatic reorder warnings.

#### Module 8: Barcode Label Printing (`/products/:id/barcode-label`)
- Thermal roll single-sticker printing (50mm x 25mm, 38mm x 25mm).
- A4 sticker sheet layouts (24 labels or 32 labels per sheet) with live printable preview.
- Includes Store Name, Product Name, Selling Price (MRP), Barcode graphic, and readable SKU.

#### Module 9: Real-Time Stock Health Monitor (`/stock`)
- Real-time stock valuation based on FIFO / Weighted Average Cost.
- Color-coded inventory health badges: In-Stock (Green), Low Stock (Amber), Stockout (Red).
- Fast filter for critical reorder points with direct "Create Purchase Order" shortcut.

#### Module 10: Stock Adjustments & Bulk CSV Import (`/inventory`)
- Manual single-item inventory adjustment with audit reason (Damage, Expiry, Physical Count Audit, Wastage).
- Bulk Excel / CSV template batch import for catalog initialization or annual stock audits.
- Movement key deduplication to prevent accidental double-adjustments.

#### Module 11: Procurement & Purchase Orders (`/purchases`)
- Inbound supplier purchase order generation.
- Itemized cost tracking, batch number capture, expiry date logging, and supplier GST calculation.
- Automatic inventory count increment upon PO status change to `Received`.

#### Module 12: Purchase Returns & Vendor Debit Notes (`/purchase-returns`)
- Supplier debit note generation for damaged or rejected goods.
- Automatic inventory deduction and vendor payable balance adjustment.

#### Module 13: Customer Directory & Khata (`/customers`)
- Comprehensive customer profiles with mobile numbers, addresses, and optional GSTINs.
- Credit limit assignment and live outstanding balance (`customer.outstanding_amount`).
- Payment collection modal supporting cash, UPI, or bank transfer with instant permanent Transaction ID.
- Complete customer Khata ledger statement view and PDF export.

#### Module 14: WhatsApp & SMS Communications (`/customers/:id/send-reminder`)
- Automated invoice PDF link dispatch via WhatsApp (Twilio integration).
- Payment collection reminders with live balance details and direct UPI payment link.
- Statement dispatch for monthly settlement reconciliation.

#### Module 15: Supplier Ledger & Accounts Payable (`/suppliers`)
- Vendor directory, contact details, payment terms, and GSTINs.
- Double-entry accounts payable ledger tracking invoice debits and payment credits.
- Disbursement voucher generation for vendor settlements.

#### Module 16: Financial Analytics & Profit Reports (`/reports`)
- Comprehensive sales volume reports grouped by day, week, month, or custom period.
- Gross profit and net margin calculations ($$\text{Margin} = \text{Selling Price} - \text{Cost Price}$$).
- Tender mix breakdown auditing cash in drawer vs digital bank collections.

#### Module 17: Statutory GST Tax Reports (`/reports/gst`)
- GSTR-1 compliant output tax statements.
- Itemized B2B invoices (with buyer GSTIN) and B2C invoices (intra-state and inter-state).
- HSN-wise tax breakdown detailing taxable values, CGST, SGST, IGST, and cess.

#### Module 18: Operating Expense Management (`/expenses`)
- Operating overhead logging: Shop Rent, Staff Salaries, Electricity, Internet, Petty Cash.
- Expense categorization and payment source tagging (Cash Drawer vs Bank Account).
- Net business profit calculation deducting overhead expenses from gross POS margins.

#### Module 19: Security Audit Trail (`/audit-trail`)
- Immutable compliance ledger logging every administrative mutation.
- Captures Operator ID, Timestamp, Action Type, Target Entity, Client IP, and Before/After JSON state diffs.
- Tracks critical events: Price overrides, invoice voids, stock adjustments, and staff permission changes.

#### Module 20: Recycle Bin & Recovery (`/recycle-bin`)
- Soft-deletion architecture for critical business records (Products, Customers, Suppliers, Categories).
- One-click restoration of accidentally deleted records.
- Permanent purge action restricted exclusively to Store Owners.

#### Module 21: Notifications & Alert Center (`/notifications`)
- Automated notification engine for:
  - Inventory items reaching or dipping below minimum threshold.
  - Overdue customer Khata credit invoices exceeding credit terms.
  - Pending supplier purchase orders awaiting warehouse receipt.
- Quick action triggers to resolve alerts directly from the drawer.

#### Module 22: Public Customer Bill Viewer (`/bill/:token`)
- Secure customer-facing digital receipt accessible via unique 24-byte cryptographic token.
- Responsive mobile layout with itemized GST breakdown, store contact details, and printable PDF download.
- Dynamic UPI payment button enabling customers to settle unpaid bills online.

#### Module 23: Canonical Short Links Service (`/s/:code/`)
- Short code generator producing compact URLs (e.g., `https://app.dreamwithtech.dev/s/X7k9Qm/`) for SMS and WhatsApp character limits.
- Automatically redirects to the secure public bill viewer.

#### Module 24: Staff Accounts & User Management (`/users`)
- Multi-user provisioning with role assignment: `owner`, `admin`, `manager`, `cashier`, `accountant`.
- Granular permission enforcement restricting cashiers from viewing profit margins or voiding bills without manager approval.
- Automatic account lockout protection against brute-force login attempts.

#### Module 25: Store Settings & Hardware Preferences (`/settings`)
- Store identity configuration: Legal Name, Trade Name, GSTIN, PAN, Address, Contact Phone, Logo.
- Receipt formatting: Header notes, footer terms, thermal printer width (80mm vs 58mm), font sizing.
- Invoice numbering controls: Configurable prefix (e.g., `INV-26-`), starting sequential counter, and financial year resets.

#### Module 26: Diagnostics, Support & Keyboard Help (`/support`)
- Real-time diagnostic ping monitoring database connectivity, cloud storage status, and API health.
- Thermal ESC/POS printer test page generator.
- Comprehensive keyboard shortcut cheat sheet for cashier onboarding.

---

### Company Admin Dashboard (`admin-frontend` – 28 Standalone Modules)

A completely decoupled SaaS administration portal for DreamWithTech corporate operations:

1. **Dashboard (`/`)**: High-level SaaS metrics (MRR, ARR, active vs trial stores, growth charts).
2. **Shops Management (`/shops`)**: Master directory of all tenant stores with status filters and search.
3. **Shop Details (`/shops/:id`)**: 360-degree merchant view across 5 tabs (Overview, Subscriptions, Staff, Payments, Audit).
4. **Add New Shop (`/shops/new`)**: Store onboarding form with live 7-character Shop ID generator.
5. **Edit Shop (`/shops/:id/edit`)**: Modify store details with permanent, locked Shop ID display.
6. **Shop Owners & Users (`/shop-owners`)**: Directory of merchant accounts with password reset capabilities.
7. **Plans and Pricing (`/plans`)**: SaaS subscription tiers (Starter ₹999/mo, Pro ₹2499/mo, Enterprise ₹5999/mo).
8. **Create Plan (`/plans/create`)**: Tier builder for limits, feature gates, and pricing models.
9. **Edit Plan (`/plans/:id/edit`)**: Modify subscription pricing and feature gate parameters.
10. **Subscriptions (`/subscriptions`)**: Active recurring mandates, renewal tracking, and status monitoring.
11. **Subscription Details (`/subscriptions/:id`)**: Detailed mandate terms, pro-rata calculations, and upgrades.
12. **Payments (`/payments`)**: Platform subscription collections, tax invoices, and settlement logs.
13. **Transactions (`/transactions`)**: Comprehensive double-entry platform ledger of credits, refunds, and gateway fees.
14. **Refunds (`/refunds`)**: Process subscription chargebacks, cancellation settlements, and dispute claims.
15. **Revenue Analytics (`/revenue-analytics`)**: In-depth unit economics: MRR, ARR, ARPU, LTV, and churn rates.
16. **Reports (`/reports`)**: Statutory GSTR-1 output tax schedule, merchant growth register, and CSV exports.
17. **Admin Users (`/admin-users`)**: DreamWithTech staff management with 2FA enforcement indicators.
18. **Roles & Permissions (`/roles`)**: Granular RBAC permission matrix (Super Admin, Finance, Support, Auditor).
19. **Activity Logs (`/activity-logs`)**: Immutable compliance audit trail of all platform-level admin actions.
20. **Notifications (`/notifications`)**: Platform alerts feed for new signups, failed renewals, and system events.
21. **Support & Helpdesk (`/support`)**: In-app merchant ticketing queue with conversation drawer and instant replies.
22. **Company Settings (`/settings`)**: Corporate profile, Razorpay/Cashfree gateway credentials, TRAI DLT SMS keys.
23. **My Profile (`/profile`)**: Personal admin credentials, password change form, and TOTP authenticator status.
24. **Login Page (`/login`)**: Secure corporate sign-in with 1-click demo credential autofill.
25. **Forgot Password (`/forgot-password`)**: Password recovery workflow with email instructions.
26. **404 Not Found (`*`)**: Custom error page with quick return to dashboard.
27. **403 Access Denied (`/403`)**: Forbidden resource warning for unauthorized staff roles.
28. **500 Server Error (`/500`)**: Platform exception screen with retry action.

---

## 6. Financial & Accounting Engineering Standards

### 1. Statutory Indian GST Engine
- **Intra-State Supply** (Store State == Customer State):
  $$\text{CGST} = \text{Taxable Value} \times \left(\frac{\text{GST Rate}}{2}\right)$$
  $$\text{SGST} = \text{Taxable Value} \times \left(\frac{\text{GST Rate}}{2}\right)$$
- **Inter-State Supply** (Store State != Customer State):
  $$\text{IGST} = \text{Taxable Value} \times \text{GST Rate}$$
- **Tax Inclusion vs Exclusion**:
  $$\text{Tax Inclusive Base} = \frac{\text{MRP}}{1 + \text{GST Rate}}$$
  $$\text{Tax Exclusive Total} = \text{Base Price} \times (1 + \text{GST Rate})$$

### 2. Double-Entry Ledger Mechanics
- Customer credit invoices debit `CustomerLedger` and increment `Customer.outstanding_amount`.
- Payment collections credit `CustomerLedger` and decrement `Customer.outstanding_amount`.
- Database constraint: `CHECK (debit = 0 OR credit = 0)`.
- Permanent Transaction ID (`TXN-...`) created exclusively upon payment collection; cannot be altered or removed.

### 3. Number & Currency Formatting Standards
All frontend displays strictly follow Indian numbering conventions:
- Currency: `₹1,25,000.00`
- Integers: `1,25,000`
- Decimals: `125.50`
- Percentages: `18.00%`
- Quantities: `1,250.500`
- Dates: `02 Nov 2026` / `02 Nov 2026, 02:45 PM`
- Numerals: Rendered with monospace tabular numerals (`font-mono tabular-nums`).
