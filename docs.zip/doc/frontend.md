# Frontend Architecture & Technical Reference

## 1. System Overview & Technology Stack

The **Billing ERP** frontend is a high-speed Single Page Application (SPA) designed specifically for retail checkout counters, inventory back-offices, and accounting desks. Built with **React 19** and bundled with **Vite 8**, it leverages **Tailwind CSS v4** to deliver an ergonomic, keyboard-driven interface with zero latency.

### Key Technology Stack
- **Core Library**: React 19 (`react`, `react-dom`)
- **Build Tool & Bundler**: Vite 8 with `@vitejs/plugin-react`
- **Styling Engine**: Tailwind CSS v4 (`@tailwindcss/vite`, `@tailwindcss/postcss`)
- **Routing**: React Router DOM v7 (`react-router-dom`)
- **Icons**: Lucide React (`lucide-react`)
- **Data Visualization**: Recharts (`recharts`)
- **Toast Notifications**: React Hot Toast (`react-hot-toast`)
- **Interactive Modals & Menus**: Headless UI (`@headlessui/react`)
- **Barcode & QR Generation**: `qrcode.react`, SVG barcode renderers
- **HTTP Client**: Axios (`axios`) with unified JWT interceptors

---

## 2. Directory Structure

```
frontend/
├── src/
│   ├── assets/              # Static media, shop logos, placeholder graphics
│   ├── components/          # Reusable shared UI primitives and structural components
│   │   ├── AppFooter.jsx    # System copyright, version info, and build status
│   │   ├── BarcodePrintModal.jsx # Multi-format barcode label printing generator
│   │   ├── CommunicationHistory.jsx # WhatsApp/SMS dispatch history drawer
│   │   ├── InvoiceDocument.jsx # ReportLab matching A4 & thermal print templates
│   │   ├── KpiCard.jsx      # High-contrast metric KPI presentation component
│   │   ├── Layout.jsx       # Global application shell (Sidebar, Topbar, Drawer)
│   │   └── UI.jsx           # Primitives (StatCard, Modal, ConfirmDialog, Table, etc.)
│   ├── features/            # Feature-specific components
│   │   └── billing/
│   │       ├── api/invoiceService.js # Billing API service calls
│   │       └── RazorpayPaymentModal.jsx # Razorpay checkout & status handler
│   ├── pages/               # Top-level route pages (26 business pages)
│   │   ├── AuditTrail.jsx   # Compliance and security audit log explorer
│   │   ├── Bills.jsx        # Historical sales invoices list and action center
│   │   ├── Customers.jsx    # Customer directory, credit management, reminders
│   │   ├── Dashboard.jsx    # Executive analytics, KPI grid, and trends
│   │   ├── Drafts.jsx       # Parked/held billing carts
│   │   ├── Expenses.jsx     # Operating expense tracking & categorization
│   │   ├── Inventory.jsx    # Stock ledger, bulk adjustments, CSV import
│   │   ├── InvoicePreview.jsx # High-fidelity A4/thermal printable invoice viewer
│   │   ├── Login.jsx        # Secure staff and administrator authentication
│   │   ├── NewBill.jsx      # High-efficiency POS checkout counter interface
│   │   ├── Notifications.jsx # Real-time alerts, low stock, approval center
│   │   ├── PaymentReconciliation.jsx # Gateway transaction audit vs local ledger
│   │   ├── Payments.jsx     # Payment ledger transactions across methods
│   │   ├── PolicyPages.jsx  # Terms of service, privacy, refund policy view
│   │   ├── Products.jsx     # Master inventory catalog, SKU, pricing, barcodes
│   │   ├── PublicBill.jsx   # Customer-facing public digital receipt view
│   │   ├── Purchases.jsx    # Supplier purchase orders and inbound inventory
│   │   ├── RecycleBin.jsx   # Soft-deleted entity management and recovery
│   │   ├── Reports.jsx      # Sales, profit, customer dues, GST filing analytics
│   │   ├── Returns.jsx      # Customer returns and credit note processing
│   │   ├── Settings.jsx     # System preferences, tax parameters, store identity
│   │   ├── Stock.jsx        # Real-time stock levels, low-stock reorder watchlist
│   │   ├── Suppliers.jsx    # Vendor directory and procurement balances
│   │   ├── Support.jsx      # Diagnostic health, FAQs, system status
│   │   └── Users.jsx        # Staff provisioning and role assignment
│   ├── api.js               # Centralized Axios client with token refresh logic
│   ├── App.css              # Custom styling, tabular fonts, print rules
│   ├── App.jsx              # Application router, route guards, lazy fallbacks
│   ├── AuthContext.jsx      # Global authentication state and permission helpers
│   ├── index.css            # Tailwind v4 configuration, theme variables, reset
│   ├── main.jsx             # React DOM root entry point
│   ├── NewBill.css          # POS screen custom layouts and print media styles
│   └── ThemeContext.jsx     # Dark / Light mode controller with localStorage persistence
├── package.json
└── vite.config.js
```

---

## 3. Global State Architecture & Contexts

### 1. `AuthContext.jsx`
Manages the user session lifecycle, token refresh loops, and role authorization.
- **State**:
  - `user`: Active user object (`{ id, username, role, business, phone }`).
  - `token`: Access JWT token string.
  - `isAuthenticated`: Boolean flag.
  - `loading`: Boolean state preventing route flicker during initial hydration.
- **Methods**:
  - `login(username, password)`: Submits credentials, stores tokens, hydrates user profile.
  - `logout()`: Clears `localStorage` (`access_token`, `refresh_token`), purges cache, resets state.
  - `hasRole(roles)`: Role-based authorization checker (`owner`, `admin`, `manager`, `cashier`, `accountant`).

### 2. `ThemeContext.jsx`
Maintains theme switching between traditional high-contrast Light mode and midnight Dark mode.
- Synchronizes with `document.documentElement.classList.add('dark')`.
- Persists user selection in `localStorage.getItem('theme')`.

### 3. Local Cart & Draft Persistence
In `NewBill.jsx` and `Drafts.jsx`:
- Active cart line items, discounts, customer selections, and notes are mirrored to `localStorage.getItem('pos_active_cart')`.
- Cashiers can "park" unfinished bills with one keystroke (F6), saving them to `localStorage.getItem('pos_drafts')` to serve the next customer without losing progress.

---

## 4. Routing Architecture & Protected Route Guards

Configured in `App.jsx` using `react-router-dom`:

```mermaid
flowchart TD
    RouteCheck{"Authenticated?"}
    UserNav["User Navigates"] --> RouteCheck
    RouteCheck -- "No" --> PublicRoutes{"Is Public Route?"}
    PublicRoutes -- "Yes (/bill/:token, /login)" --> RenderPublic["Render Page"]
    PublicRoutes -- "No" --> RedirectLogin["Redirect to /login"]
    
    RouteCheck -- "Yes" --> LayoutShell["Mount Layout Shell"]
    LayoutShell --> RoleCheck{"Role Authorized?"}
    RoleCheck -- "Yes" --> RenderPage["Render Protected View"]
    RoleCheck -- "No (e.g. Cashier on /settings)" --> RenderForbidden["Redirect to /pos (New Bill)"]
```

### Route Index
| Route | Component | Access Control |
|---|---|---|
| `/login` | `Login.jsx` | Public |
| `/bill/:token` | `PublicBill.jsx` | Public (End-Customer Digital Bill) |
| `/` | `Dashboard.jsx` | Authenticated (Admin/Manager/Accountant) |
| `/pos` | `NewBill.jsx` | Authenticated (All Roles) |
| `/bills` | `Bills.jsx` | Authenticated (All Roles) |
| `/drafts` | `Drafts.jsx` | Authenticated (All Roles) |
| `/returns` | `Returns.jsx` | Authenticated (Admin/Manager/Cashier) |
| `/payments` | `Payments.jsx` | Authenticated (Admin/Manager/Accountant) |
| `/reconciliation` | `PaymentReconciliation.jsx` | Authenticated (Admin/Accountant) |
| `/products` | `Products.jsx` | Authenticated (All Roles) |
| `/stock` | `Stock.jsx` | Authenticated (All Roles) |
| `/inventory` | `Inventory.jsx` | Authenticated (Admin/Manager) |
| `/purchases` | `Purchases.jsx` | Authenticated (Admin/Manager) |
| `/customers` | `Customers.jsx` | Authenticated (All Roles) |
| `/suppliers` | `Suppliers.jsx` | Authenticated (Admin/Manager) |
| `/expenses` | `Expenses.jsx` | Authenticated (Admin/Accountant) |
| `/reports` | `Reports.jsx` | Authenticated (Admin/Accountant) |
| `/notifications` | `Notifications.jsx` | Authenticated (All Roles) |
| `/audit-trail` | `AuditTrail.jsx` | Authenticated (Admin/Owner) |
| `/recycle-bin` | `RecycleBin.jsx` | Authenticated (Admin/Owner) |
| `/users` | `Users.jsx` | Authenticated (Admin/Owner) |
| `/settings` | `Settings.jsx` | Authenticated (Admin/Owner) |
| `/invoice/:id` | `InvoicePreview.jsx` | Authenticated (All Roles) |

---

## 5. Global Shell: Sidebar & Topbar (`Layout.jsx`)

The global layout provides rapid keyboard navigation and situational awareness across long POS shifts:

### Sidebar Features
- **Collapsible Rail**: Toggles between full 260px width and compact 64px icon rail mode with hover tooltips.
- **Grouped Accordions**:
  - **Overview**: Dashboard, Notifications.
  - **Sales**: POS (New Bill), Invoices, Drafts, Returns, Payments, Reconciliation.
  - **Inventory**: Products, Stock, Inventory Ledger, Purchase Orders.
  - **Parties**: Customers, Suppliers.
  - **Finance & Compliance**: Reports, Expenses, Audit Trail, Recycle Bin.
  - **System**: Users, Settings, Support.
- **Active Navigation Highlighting**: High-contrast dark navy background (`#1E3A5F`) with crisp left border indicator.
- **Mobile Responsive Drawer**: Off-canvas slide-in drawer on viewports `< 1024px` with backdrop tap dismissal.

### Topbar Features
- **Omnisearch (`Ctrl + K`)**: Instant search overlay querying products by SKU/barcode, customers by phone, and invoices by invoice number with keyboard selection (`↑`, `↓`, `Enter`).
- **Live POS Clock**: Ticking digital clock with seconds to track shift timings and receipt timestamps.
- **Notification Bell**: Actionable alert badge showing unread count, with quick flyout menu deep-linking directly to low-stock or overdue accounts.
- **User Avatar & Store Switcher**: Displays current operator initials, role pill, dark/light theme switch, and sign-out.

---

## 6. High-Efficiency POS Screen (`NewBill.jsx`)

The POS interface is optimized for rapid retail checkout with **zero mouse dependency**:

```
+-----------------------------------------------------------+---------------------------------+
|  BARCODE / SEARCH INPUT (Auto-focused, scanner ready)    |  CUSTOMER SELECTION             |
+-----------------------------------------------------------+  [ Walk-in Customer ] [+] Add   |
|  CATEGORY QUICK-PICK PILLS                                +---------------------------------+
|  [ All ] [ Grocery ] [ Dairy ] [ Snacks ] [ Beverages ]   |  BILL TOTALS SUMMARY            |
+-----------------------------------------------------------+  Subtotal:             1,240.00 |
|  ITEMIZED CART TABLE                                      |  Discount:               -40.00 |
|  Product Name    | MRP  | Rate | Qty | Total | Actions    |  GST (CGST+SGST):         60.00 |
|  ----------------|------|------|-----|-------|---------   |  Round Off:               +0.00 |
|  Organic Milk 1L |  65  |  60  | [2] | 120   | [x]        |  ------------------------------ |
|  Whole Wheat     |  55  |  50  | [1] |  50   | [x]        |  GRAND TOTAL:       ₹1,260.00   |
|                                                           +---------------------------------+
|                                                           |  PAYMENT METHOD                 |
|                                                           |  [Cash] [UPI QR] [Card] [Credit]|
|                                                           +---------------------------------+
|                                                           |  CASH TENDER KEYPAD             |
|                                                           |  Tendered: [ 1500 ]             |
|                                                           |  Change Due: ₹240.00            |
|                                                           +---------------------------------+
|  [F1 Search]  [F6 Park]  [F7 Thermal]  [F8 Save & Print]  |  [ SAVE & PRINT BILL (F8) ]     |
+-----------------------------------------------------------+---------------------------------+
```

### Keyboard Shortcuts Reference
- `F1` / `Ctrl + K`: Focus barcode / product search input.
- `F2`: Open Customer selection / new customer modal.
- `F4`: Cycle payment methods (Cash → UPI → Card → Credit).
- `F6`: Park active cart as a draft bill.
- `F7`: Print preview thermal receipt.
- `F8`: Execute, tender, and print bill immediately.
- `Esc`: Clear search / close open modal.
- `+` / `-`: Increment/decrement quantity of currently highlighted cart row.

---

## 7. Core Screen & Feature Workflows

### 1. Executive Dashboard (`Dashboard.jsx`)
- **KPI Metrics Grid**: Standardized KPI cards tracking Today's Gross Sales, Profit & Net Margin %, Bill Count, Collection by Tender, Low Stock Alerts, and Outstanding Customer Credit.
- **Recharts Data Visualizations**:
  - 7-Day Revenue Trend (Smooth AreaChart).
  - Hourly Sales Peak Heatmap (BarChart).
  - Tender Distribution (Donut chart).
- **Watchlist & Action Items**: Tabular display of out-of-stock items needing replenishment and recent bills with 1-click view and reprint buttons.

### 2. Barcode Label Generator (`BarcodePrintModal.jsx`)
- Allows generating printable barcode tags for any catalog product.
- Supports thermal barcode label rolls (single column 50x25mm, 38x25mm) and full A4 sticker sheets (4x8 32-labels/page, 3x8 24-labels/page).
- Live real-time preview showing shop name, product title, barcode, and MRP.

### 3. Payment Reconciliation (`PaymentReconciliation.jsx`)
- Compares Razorpay online gateway captured transactions against local database invoices.
- Filters by status (`captured`, `initiated`, `pending`, `failed`, `refunded`).
- Highlights unsettled gateway fees, GST deductions, and net payouts.

### 4. Customer Ledger & Credit Recovery (`Customers.jsx`)
- Tracks customer balances and credit limits.
- Features a 1-click **Send WhatsApp Reminder** action using pre-formatted payment links and outstanding balance notifications.
- Complete ledger view itemizing invoice debits and payment receipts.

### 5. Document Printing Engine (`InvoiceDocument.jsx`)
- Implements two render engines:
  1. **A4 Tax Invoice**: Dual party GST breakdown, bank account details, authorized signature.
  2. **Thermal POS Receipt**: High-density 80mm/58mm format designed for ESC/POS receipt printers via `window.print()`.

---

## 8. API Client & HTTP Interceptors (`api.js`)

API communication is encapsulated in a configured Axios instance with automated token refresh rotation:

```javascript
// Request Interceptor: Injects Authorization Bearer Token
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('access_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Response Interceptor: Handles 401 Unauthorized via Refresh Token
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;
    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;
      const refreshToken = localStorage.getItem('refresh_token');
      if (refreshToken) {
        try {
          const res = await axios.post('/api/auth/refresh/', { refresh: refreshToken });
          localStorage.setItem('access_token', res.data.access);
          originalRequest.headers.Authorization = `Bearer ${res.data.access}`;
          return api(originalRequest);
        } catch {
          localStorage.clear();
          window.location.href = '/login';
        }
      }
    }
    return Promise.reject(error);
  }
);
```

---

## 9. Build, Performance & Optimization

- **Bundle Size Optimization**: Heavy third-party modules (`recharts`, `lucide-react`) are tree-shaken by Vite.
- **CSS Pre-compilation**: Tailwind CSS v4 compiles directly without runtime CSS-in-JS overhead.
- **Production Build Command**:
  ```bash
  cd frontend
  npm run build
  ```
- Generates optimized static assets in `frontend/dist/` ready for serving via Nginx, Render static sites, or Django WhiteNoise.
