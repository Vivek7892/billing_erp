# Billing ERP — Comprehensive Project Report

**Enterprise Cloud Point-of-Sale (POS) & Business Management System**  
 _Comprehensive Technical & Functional Project Documentation_

---

## 1. Executive Summary

The **Billing ERP** system is an enterprise-grade cloud Point-of-Sale (POS), inventory control, and retail ERP solution engineered for grocery stores, supermarkets, retail outlets, and wholesale distribution businesses.

Designed to overcome the limitations of sluggish legacy desktop billing software, this platform combines a **high-concurrency Django REST backend** with an **ergonomic, keyboard-driven React 19 single-page application (SPA)**. It delivers sub-second barcode checkout, automated GST calculation, double-entry customer and vendor ledgers, real-time inventory adjustments, payment reconciliation with Razorpay, automated WhatsApp billing dispatch, and a comprehensive compliance audit trail.

```
+-----------------------------------------------------------------------------------------+
|                                    BILLING ERP PLATFORM                                 |
+-----------------------------------------------------------------------------------------+
|  FRONTEND LAYER        |  React 19 · Vite 8 · Tailwind CSS v4 · Recharts · Lucide       |
|  API / BACKEND LAYER   |  Django 4.2 · Django REST Framework · SimpleJWT · ReportLab   |
|  DATA & STORAGE LAYER  |  PostgreSQL / SQLite · Supabase Cloud Storage · WhiteNoise     |
|  INTEGRATION LAYER     |  Razorpay Gateway · Twilio WhatsApp/SMS · ESC/POS & A4 Print   |
+-----------------------------------------------------------------------------------------+
```

---

## 2. Problem Statement & Business Objectives

### The Retail & Wholesale Billing Challenge

Small-to-medium retail enterprises (SMEs) face critical operational bottlenecks:

1. **Slow Checkout Lines**: Traditional billing systems require extensive mouse clicking, slowing down cashier throughput during peak store hours.
2. **Inventory Stockout & Pilferage**: Inaccurate stock tracking leads to surprise stockouts, unrecorded damages, and inventory leakage.
3. **Credit (Khata) Default Risks**: Retail stores extending customer credit struggle with fragmented paper ledger books, resulting in delayed collections and unrecoverable debts.
4. **GST Tax Compliance Complexity**: Miscalculations in CGST/SGST splits, HSN codes, and round-offs cause tax filing discrepancies.
5. **Lack of Integrated Digital Experience**: Customers expect digital receipts on WhatsApp and UPI QR payments, which legacy desktop software cannot provide.

### Core Business Objectives

- **Zero-Latency Checkout**: Provide an ergonomic POS screen with full keyboard shortcut support (`F1` to `F8`) enabling cashier checkout in under 15 seconds per customer.
- **Strict Accounting Integrity**: Enforce double-entry bookkeeping across customer and supplier balances with database-level non-negative constraints.
- **Automated Omnichannel Communication**: Send instant digital invoices and payment reminders via WhatsApp.
- **Auditable Security**: Log every sensitive action (price overrides, invoice voiding, refunds) in an immutable audit trail with before/after state diffs.

---

## 3. High-Level System Architecture

```mermaid
flowchart TB
    subgraph Client["Presentation Layer (Client SPA)"]
        UI["React 19 SPA (Vite 8)"]
        POS["High-Speed POS Interface"]
        AdminUI["Management Dashboard"]
        PublicUI["Customer Digital Bill View"]
    end

    subgraph Gateway["Network & Edge Layer"]
        Nginx["Reverse Proxy / SSL"]
        WhiteNoise["Static Assets & Brotli"]
    end

    subgraph Backend["Application Layer (Django 4.2 REST)"]
        Auth["JWT & RBAC Security"]
        POSService["Invoice & Inventory Lock Engine"]
        LedgerService["Double-Entry Ledger Engine"]
        ReportLab["PDF & Barcode Generator"]
        NotifService["Notification & Alert Worker"]
    end

    subgraph Data["Persistence & External Services"]
        DB[("PostgreSQL / SQLite")]
        Storage["Supabase Storage"]
        Razorpay["Razorpay Payment Gateway"]
        Twilio["Twilio WhatsApp API"]
    end

    UI --> Nginx
    Nginx --> WhiteNoise
    Nginx --> Backend
    POS --> POSService
    AdminUI --> LedgerService
    Backend --> DB
    Backend --> Storage
    Backend --> Razorpay
    Backend --> Twilio
```

---

## 4. Functional Module Inventory

The Billing ERP platform includes 26 integrated business modules:

| #      | Module                      | Key Capabilities                                                                                                                                                           | Target User Role  |
| ------ | --------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------- |
| **1**  | **POS / New Bill**          | Auto-focus barcode scanning, quick-pick category grid, tabular cart, cash tender denomination keypad, dynamic UPI QR modal, local cart draft persistence.                  | Cashier, Admin    |
| **2**  | **Executive Dashboard**     | Real-time KPI metrics (Revenue, Profit Margin, Bill Count, Dues), Recharts 7-day revenue trend, hourly sales peak heatmap, tender distribution donut, low-stock watchlist. | Owner, Admin      |
| **3**  | **Invoice Management**      | Historical bills directory, multi-parameter filtering, invoice voiding/cancellation with reason capture, credit note generation, A4 & thermal reprinting.                  | Cashier, Admin    |
| **4**  | **Payment Reconciliation**  | Compares captured Razorpay gateway transactions against local records, auditing gateway fees, GST deductions, and net settled amounts.                                     | Accountant, Admin |
| **5**  | **Drafts & Parked Bills**   | One-key parking (`F6`) of active checkout carts, allowing cashiers to suspend transactions during customer delays and resume later.                                        | Cashier           |
| **6**  | **Sales Returns & Refunds** | Item-level customer returns, reason capture, restocking control, cash/credit refund settlement, credit note issuance.                                                      | Manager, Admin    |
| **7**  | **Master Product Catalog**  | SKU, barcode (UPC/EAN/Code128), HSN code, cost price, selling price, MRP, GST slab (0-28%), unit type, minimum stock threshold.                                            | Manager, Admin    |
| **8**  | **Barcode Label Generator** | Print custom barcode labels on thermal rolls (single sticker) or A4 sticker sheets (24/32 labels per page) with live interactive preview.                                  | Manager, Admin    |
| **9**  | **Real-Time Stock Monitor** | Color-coded inventory health indicators (in-stock, low-stock, stockout), reorder point monitoring, supplier mapping.                                                       | All Staff         |
| **10** | **Inventory Adjustments**   | Single-item adjustments, bulk stock reconciliation, and Excel/CSV template batch import with movement key deduplication.                                                   | Manager, Admin    |
| **11** | **Procurement & POs**       | Supplier purchase orders, itemized inbound cost tracking, GST tax calculation, automatic inventory increment on receipt.                                                   | Manager, Admin    |
| **12** | **Purchase Returns**        | Supplier debit notes, return order management, inventory deduction, outstanding balance reduction.                                                                         | Manager, Admin    |
| **13** | **Customer Ledger & Khata** | Customer profiles, credit limit enforcement, outstanding receivables tracking, payment entry modal, statement download.                                                    | Cashier, Admin    |
| **14** | **WhatsApp Reminders**      | Automated dispatch of payment collection reminders and official invoice links to customer mobile numbers via Twilio.                                                       | Cashier, Admin    |
| **15** | **Supplier Ledger**         | Vendor credit management, outstanding payable balances, payment disbursement logging, payment vouchers.                                                                    | Accountant, Admin |
| **16** | **Financial Reports**       | Detailed sales volume reports, gross/net profit margin analytics, customer aging credit reports, payment tender distribution.                                              | Accountant, Admin |
| **17** | **GST Tax Filing Report**   | GSTR-1 compliant tax summaries itemizing B2B, B2C, HSN-wise tax distribution (CGST, SGST, IGST) with Excel export.                                                         | Accountant, Admin |
| **18** | **Expense Management**      | Operating overhead tracking (rent, electricity, salaries, petty cash), expense categories, cash vs bank settlement logs.                                                   | Accountant, Admin |
| **19** | **Security Audit Trail**    | Immutable log tracking every sensitive action with operator ID, IP address, user agent, and before/after JSON diffs.                                                       | Owner, Admin      |
| **20** | **Recycle Bin (Trash)**     | Soft-deletion architecture allowing recovery of accidentally deleted products, customers, suppliers, and categories.                                                       | Owner, Admin      |
| **21** | **Notifications Center**    | Automated deduplicated alerts for low stock, overdue customer invoices, and pending purchase orders with quick-action buttons.                                             | All Staff         |
| **22** | **Public Customer Bill**    | Secure customer-facing digital receipt accessible via unique 24-byte token (`/bill/<token>`) with responsive mobile layout and PDF download.                               | End Customer      |
| **23** | **Short Links Service**     | Canonical 6-character short link generator (`/s/<code>/`) for compact SMS and WhatsApp bill sharing.                                                                       | End Customer      |
| **24** | **User Management**         | Staff provisioning, role assignment (`owner`, `admin`, `manager`, `cashier`, `accountant`), account lockouts on failed attempts.                                           | Owner, Admin      |
| **25** | **Business Settings**       | Store identity, GSTIN, PAN, receipt headers/footers, invoice numbering prefix/counter, thermal printer options.                                                            | Owner, Admin      |
| **26** | **Support & Diagnostics**   | System health status, database ping, printer test tool, keyboard shortcut cheat sheet, built-in FAQs.                                                                      | All Staff         |

---

## 5. Technical Specifications & Financial Engineering

### 1. Statutory GST Engine

The platform complies with standard Indian Goods & Services Tax (GST) rules:

- **Intra-State Supply**: When the store state matches the Place of Supply, tax is split equally:
  $$\text{CGST} = 50\% \times \text{GST Amount}, \quad \text{SGST} = 50\% \times \text{GST Amount}$$
- **Inter-State Supply**: When goods cross state borders, integrated tax is charged:
  $$\text{IGST} = 100\% \times \text{GST Amount}$$
- **HSN Code Tracking**: Mandatory HSN code mapping per product for statutory audit compliance.

### 2. Double-Entry Ledger Mechanics

The platform implements strict double-entry ledger bookkeeping:

- Every customer invoice with `payment_method = 'credit'` creates a debit entry on `CustomerLedger` and increments `customer.outstanding_amount`.
- Every settlement payment creates a credit entry on `CustomerLedger` and decrements `customer.outstanding_amount`.
- A database constraint ensures `debit = 0 OR credit = 0`, preventing corrupted two-sided ledger rows.

### 3. Concurrency & Inventory Lock

To prevent inventory overselling during simultaneous checkouts across multiple counters:

- Transactions wrap invoice creation in `transaction.atomic()`.
- Product stock is validated and deducted atomically using `select_for_update()`.
- Every stock movement is logged with a unique `movement_key` to guarantee idempotency.

---

## 6. Security, Authentication & Auditability

### Multi-Tier Authentication

1. **JWT Bearer Token Flow**: Access token (15-minute expiry) paired with a persistent refresh token stored in encrypted browser storage.
2. **Account Lockout Protection**: Automatic account freeze after 5 consecutive failed login attempts, logged to `AuditLog`.
3. **Role-Based Access Control (RBAC)**: Strict permission decorators (`IsAdminOrOwner`, `IsManagerOrAdmin`) enforced across all API endpoints.

### Cryptographic Public Access

- Public customer receipts do not expose internal database IDs.
- Invoices are accessed via high-entropy `public_token` strings (`secrets.token_urlsafe(24)`), preventing enumeration attacks.

---

## 7. Deployment & Infrastructure

```
+-------------------------------------------------------------------------------+
|                             PRODUCTION DEPLOYMENT                             |
+-------------------------------------------------------------------------------+
|  WEB SERVICES       |  Render Cloud Container Platform                        |
|  WSGI APPLICATION   |  Gunicorn (Worker concurrency: 4)                       |
|  STATIC ASSETS      |  WhiteNoise with Brotli & Gzip compression              |
|  DATABASE           |  Managed PostgreSQL 15+ (SSL Enforced)                  |
|  MEDIA STORAGE      |  Supabase Object Storage (S3 API Compatible)            |
|  ENVIRONMENT CONFIG |  python-decouple (.env injection)                       |
+-------------------------------------------------------------------------------+
```

### Essential Environment Configuration

```ini
# Core Django
SECRET_KEY=production-secure-random-key
DEBUG=False
ALLOWED_HOSTS=.onrender.com,localhost,127.0.0.1
DATABASE_URL=postgresql://user:password@host:port/dbname

# Frontend & Short Links
FRONTEND_URL=https://billing-pos.vercel.app
BACKEND_URL=https://billing-erp-api.onrender.com

# Payment Gateway (Razorpay)
RAZORPAY_KEY_ID=rzp_live_xxxxxxxxxxxx
RAZORPAY_KEY_SECRET=xxxxxxxxxxxxxxxxxxxxxxxx
RAZORPAY_WEBHOOK_SECRET=xxxxxxxxxxxxxxxxxxxx

# Telephony & WhatsApp (Twilio)
TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
TWILIO_AUTH_TOKEN=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
TWILIO_WHATSAPP_FROM=whatsapp:+14155238886

# Cloud Object Storage (Supabase)
SUPABASE_URL=https://xxxxxxxxxxxx.supabase.co
SUPABASE_KEY=eyxxxxxxxxxxxxxxxxxxxxxxxx
SUPABASE_BUCKET_NAME=erp-media
```

---

## 8. Verification, Testing & Quality Assurance

### Test Suite Execution

- **Backend Unit & Integration Tests**:
  - `python manage.py test api`: Passes all test suites including calculations, business rules, public bills, and audit operations.
- **Frontend Production Compilation**:
  - `npm run build`: Compiles cleanly in 1.14s with Vite 8 and zero JSX/CSS errors.

---

## 9. Conclusion & Project Achievements

The **Billing ERP** platform successfully bridges the gap between traditional accounting stability and modern cloud speed. By establishing a dedicated design system, rigorous ledger accounting, and an ergonomic POS workflow, the application delivers:

- **Sub-15-second customer checkout speeds** for retail counters.
- **Zero discrepancy financial ledgers** enforced by relational database constraints.
- **Modern omnichannel digital billing** via WhatsApp and dynamic UPI QR codes.
- **Unified professional enterprise design** across all 26 application screens.
