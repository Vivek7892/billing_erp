# Design System & Styling Guide

## 1. Design Philosophy

The **Billing ERP Design System** is crafted specifically for traditional retail, wholesale, and supermarket operations. Unlike modern consumer SaaS applications that prioritize decorative gradients, heavy illustrations, neon badges, and oversized padding, this ERP system adheres to the standards of professional accounting and POS environments:

- **High Information Density**: Compact spacing and restrained padding allow cashiers and accountants to review complex tables without unnecessary scrolling.
- **Cognitive Clarity**: Restrained color usage ensures that color draws attention strictly to semantic meanings (overdue balances, stockouts, errors, successful settlements).
- **Tabular Alignment**: Every financial figure, stock quantity, invoice number, and timestamp is rendered using monospaced, tabular numbers (`tabular-nums`) for rapid vertical visual scanning.
- **High Contrast & Readability**: Crisp borders (`#D7DEE7`) and sharp ink text (`#172033`) ensure readability under fluorescent store lighting and on diverse POS monitor hardware.

---

## 2. Core Color Tokens & Palette

```
+-----------------------------------------------------------------------------------+
|  PRIMARY NAVY       |  SECONDARY SLATE   |  ACCENT TEAL      |  INK (MAIN TEXT)   |
|  #1E3A5F            |  #475569           |  #0F766E          |  #172033           |
+---------------------+--------------------+-------------------+--------------------+
|  PAGE BACKGROUND    |  CARD SURFACE      |  BORDER LINE      |  MUTED TEXT        |
|  #F8FAFC            |  #FFFFFF           |  #D7DEE7          |  #64748B           |
+-----------------------------------------------------------------------------------+
```

### Complete Palette Specification

| Token Name | Hex Code | Tailwind / CSS Variable | Purpose & Usage |
|---|---|---|---|
| **Primary Navy** | `#1E3A5F` | `--primary`, `bg-[#1E3A5F]` | Primary actions, main navigation active states, brand headers |
| **Primary Hover** | `#162F4D` | `--primary-hover` | Hover state for primary buttons |
| **Primary Active** | `#0F1F33` | `--primary-active` | Active/pressed state for primary buttons |
| **Secondary Slate** | `#475569` | `--slate`, `text-[#475569]` | Secondary labels, neutral icons, subtle borders |
| **Slate Hover** | `#334155` | `hover:text-[#334155]` | Hover state for secondary actions |
| **Accent Teal** | `#0F766E` | `--accent`, `text-[#0F766E]` | Procurement indicators, margin metrics, growth trends |
| **Main Text (Ink)** | `#172033` | `--ink`, `text-[#172033]` | Primary headings, table text, customer names |
| **Secondary Text** | `#64748B` | `--ink-secondary` | Descriptions, phone numbers, table subtitles |
| **Muted Text** | `#94A3B8` | `--muted`, `text-[var(--muted)]` | Table headers, metadata timestamps, field labels |
| **Border Line** | `#D7DEE7` | `--line`, `border-[#D7DEE7]` | Card borders, table dividers, input borders |
| **Page Background** | `#F8FAFC` | `--app-bg`, `bg-[#F8FAFC]` | Application canvas background |
| **Surface White** | `#FFFFFF` | `--surface`, `bg-[#FFFFFF]` | Cards, modals, topbar, table row backgrounds |
| **Surface Elevated** | `#F1F5F9` | `--surface-elevated` | Table headers, secondary control backgrounds |

### Semantic Colors

Semantic colors are strictly reserved for functional messaging and data states:

| Semantic Intent | Hex Code | Light Mode Class | Dark Mode Class |
|---|---|---|---|
| **Success / Paid / Settled** | `#15803D` | `text-[#15803D]` | `dark:text-emerald-400` |
| **Warning / Pending / Low Stock** | `#B45309` | `text-[#B45309]` | `dark:text-amber-400` |
| **Error / Void / Destructive** | `#B91C1C` | `text-[#B91C1C]` | `dark:text-red-400` |
| **Info / Initiated / Links** | `#2563EB` | `text-[#2563EB]` | `dark:text-blue-400` |
| **Refund / Return / Reversal** | `#C2410C` | `text-[#C2410C]` | `dark:text-orange-400` |

---

## 3. Typography & Tabular Numerics

### Font Family
- **Interface Font**: System UI stack (`system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif`).
- **Financial & Code Font**: Monospaced tabular font stack (`ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', monospace`).

### Type Scale Hierarchy
- **Page Title**: `text-xl sm:text-2xl font-bold tracking-tight text-[var(--ink)]`
- **Section Heading**: `text-xs font-bold uppercase tracking-wider text-[var(--ink)]`
- **Field / Table Header**: `text-[10px] font-bold uppercase tracking-wider text-[var(--muted)]`
- **Body Text**: `text-sm text-[var(--ink)]`
- **Supporting / Metadata**: `text-xs text-[var(--muted)]`
- **Tabular Monetary Figures**: `font-mono text-base font-bold text-[var(--ink)] tabular-nums`

---

## 4. Button & Control Hierarchy

Buttons follow a strict four-tier hierarchy to eliminate cognitive overload:

```
+-----------------------------------------------------------------------+
| 1. PRIMARY ACTION        |  [ Save & Print Bill (F8) ]                |
|    Solid Dark Navy       |  bg-[#1E3A5F] text-white hover:bg-[#162F4D] |
+--------------------------+--------------------------------------------+
| 2. SECONDARY ACTION      |  [ Cancel / Hold ]                         |
|    White Surface + Line  |  bg-white border-[#D7DEE7] text-[#475569]   |
+--------------------------+--------------------------------------------+
| 3. ACTION ICON BUTTON    |  [ <Eye> ]  [ <Printer> ]  [ <Trash> ]     |
|    Compact Icon Box      |  bg-white border-[#D7DEE7] text-[#475569]   |
+--------------------------+--------------------------------------------+
| 4. DESTRUCTIVE ACTION    |  [ Void Invoice ]                          |
|    Semantic Red          |  bg-[#B91C1C] text-white hover:bg-[#991B1B] |
+-----------------------------------------------------------------------+
```

### Component CSS Classes
- `.btn-primary`:
  ```css
  display: inline-flex;
  align-items: center;
  justify-content: center;
  height: 2.5rem;
  padding: 0 1rem;
  font-size: 0.875rem;
  font-weight: 600;
  border-radius: 0.375rem;
  background-color: #1E3A5F;
  color: #FFFFFF;
  border: 1px solid transparent;
  transition: all 150ms ease;
  ```
- `.btn-secondary`:
  ```css
  display: inline-flex;
  align-items: center;
  justify-content: center;
  height: 2.5rem;
  padding: 0 1rem;
  font-size: 0.875rem;
  font-weight: 600;
  border-radius: 0.375rem;
  background-color: #FFFFFF;
  color: #475569;
  border: 1px solid #D7DEE7;
  transition: all 150ms ease;
  ```
- `.icon-btn` / `.btn-icon`:
  ```css
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 2rem;
  height: 2rem;
  border-radius: 0.375rem;
  background-color: #FFFFFF;
  border: 1px solid #D7DEE7;
  color: #475569;
  transition: all 150ms ease;
  ```

---

## 5. Standard KPI Metrics Grid

KPI displays follow the strict retail specification:

| Element | Style & Utility Classes |
|---|---|
| **Container** | `rounded-md border border-[var(--line)] bg-[var(--surface)] shadow-none` |
| **Grid** | `grid grid-cols-2 sm:grid-cols-4` |
| **Dividers** | `divide-y divide-[var(--line-subtle)] sm:divide-y-0 sm:divide-x sm:divide-[var(--line)]` |
| **Padding** | `p-3 sm:p-3.5` |
| **Label** | `text-[10px] font-bold uppercase tracking-wider text-[var(--muted)]` |
| **Main Value** | `font-mono text-lg sm:text-xl font-bold text-[var(--ink)] tabular-nums` |
| **Paid / Revenue Value** | `text-[#15803D] dark:text-emerald-400 font-mono font-bold` |
| **Accent / Trend Value** | `text-[#1E3A5F] dark:text-slate-100 font-mono font-bold` |
| **Supporting Subtitle** | `text-[10px] text-[var(--muted)] mt-0.5` |
| **Icons & Shadows** | **None** (Clean typography only) |

---

## 6. Table System (`.erp-table`)

Data grids are optimized for high-volume transactions:
- **Header (`<thead>`)**:
  - `bg-[var(--surface-elevated)] border-b border-[var(--line)]`
  - `text-[10px] font-bold uppercase tracking-wider text-[var(--muted)] py-2.5 px-3`
- **Body Rows (`<tbody>`)**:
  - `divide-y divide-[var(--line-subtle)]`
  - `hover:bg-[var(--surface-hover)] transition-colors`
  - `py-2.5 px-3 text-xs text-[var(--ink)]`
- **Monetary / Numeric Columns**:
  - `text-right font-mono font-semibold tabular-nums`

---

## 7. Form Controls & Inputs

- **Input Shell**: `h-9 rounded-md border border-[var(--line)] bg-[var(--surface)] px-3 text-xs text-[var(--ink)] transition-colors placeholder:text-[var(--muted-light)]`
- **Focus Ring**: `focus:border-[#1E3A5F] focus:outline-none focus:ring-2 focus:ring-[#1E3A5F]/15`
- **Checkbox / Radio**: `h-4 w-4 rounded border-[var(--line)] text-[#1E3A5F] accent-[#1E3A5F] focus:ring-[#1E3A5F]/20`

---

## 8. Modals, Sheets & Overlays

- **Backdrop**: `bg-black/50 backdrop-blur-[2px] transition-opacity`
- **Modal Container**: `rounded-lg border border-[var(--line)] bg-[var(--surface)] p-5 sm:p-6 shadow-xl`
- **Header**: Clean border bottom `border-b border-[var(--line)] pb-3 flex items-center justify-between`
- **Footer**: `border-t border-[var(--line)] pt-3 flex items-center justify-end gap-2`

---

## 9. Negative Constraints (Strict Rules)

1. **NO SaaS Purples / Violets**: Never use `#4F46E5`, `#6366F1`, `#7C3AED`, `bg-indigo-*`, or `bg-purple-*`.
2. **NO Decorative Gradients**: Never use `bg-gradient-to-r` or multi-stop linear gradients on buttons, headers, or cards.
3. **NO Colored Pill Badges for Payment Methods**: Cash, UPI, Card, and Credit must use clean text with subtle borders or icons, never large colored pills.
4. **NO Excessive Rounded Borders**: Use standard `rounded-md` (6px) or `rounded-lg` (8px). Never use `rounded-3xl` or `rounded-full` on cards or containers.
5. **NO Neon Accents or Heavy Glows**: Shadows are limited to `shadow-none` or subtle `shadow-xs`. Glassmorphism and frosted glowing panels are forbidden.
