# Project Memory, Technical Decisions & Operational Notes

**Project**: DreamWithTech Billing ERP  
**Purpose**: Central knowledge repository capturing architectural decisions, rationale, environmental configurations, and critical technical notes for engineering teams and AI coding agents.

---

## 1. Key Architectural Decisions & Rationale

### 1. Decoupled Multi-Application Architecture
- **Decision**: Separate the platform into two independent frontend applications:
  1. `frontend/` (`https://app.dreamwithtech.dev`): Store POS & Merchant Management.
  2. `admin-frontend/` (`https://admin.dreamwithtech.dev`): Company Admin Dashboard.
- **Rationale**: Strict tenant isolation. Store merchants must never share frontend routing, asset bundles, or session state with corporate SaaS administrators. A security breach in a merchant browser session cannot expose platform administration controls.

### 2. Styling Technology Separation (Strict Constraint)
- **Decision**: Use Tailwind CSS v4 in `frontend/`, but **strictly Pure CSS Modules and CSS Custom Properties** in `admin-frontend/`.
- **Rationale**: Explicit user mandate prohibiting Tailwind CSS in `admin-frontend/`. This ensures the corporate admin portal retains a restrained, bespoke enterprise aesthetic with no CSS framework collisions, custom variables, and ultra-compact chunk sizes.

### 3. Standardized 7-Character Shop ID (`DWAAYYNN`)
- **Decision**: Every tenant store is assigned an immutable 7-character Shop ID matching `^DW[A-Z]{2}[0-9]{4}$` (e.g., `DWKT2618`).
- **Rationale**:
  - `DW`: Fixed DreamWithTech brand identifier.
  - `AA`: Two random uppercase letters providing 676 combinations per year.
  - `YY`: 2-digit registration year (e.g., `26` for 2026).
  - `NN`: Two random digits providing 100 combinations per letter pair.
  - Total entropy: $676 \times 100 = 67,600$ new shops per year before collision, regenerated automatically if a collision occurs.
  - Why not sequential? Sequential IDs leak merchant signup volume to competitors.
  - Why immutable? Prevents broken billing references, gateway mandates, or audit trail corruption.

### 4. Retired Shop ID Tracking (`RetiredShopID`)
- **Decision**: Maintain a dedicated `RetiredShopID` database table recording decommissioned Shop IDs.
- **Rationale**: If a merchant deletes their account, their Shop ID must **never be recycled** for a new merchant. This preserves statutory audit trails and prevents misdirected payments or WhatsApp receipts.

### 5. Permanent Transaction ID Generation
- **Decision**: Payment collection transaction IDs (`TXN-YYYYMMDD-XXXXXX`) are generated **only upon collection of payment** and made immutable.
- **Rationale**: Generating IDs prior to payment creates orphaned transaction numbers and invites fraud. Making them immutable ensures the financial payment history cannot be tampered with.

### 6. Standardized Indian Formatting Utilities
- **Decision**: Centralize all number and currency formatting into `frontend/src/utils/formatters.js` and `admin-frontend/src/utils/formatters.js`.
- **Rationale**: Prevents inconsistent decimal display across disparate components. Standardizes currency to `₹1,25,000.00`, quantities to `1,250.500`, and percentages to `18.00%` across the entire codebase.

### 7. Simple Text Back Button Navigation Pattern
- **Decision**: Replace complex or inconsistent navigational controls with a simple text-format button (`Back` with an `ArrowLeft` icon) at the top of detail and form pages on both mobile and desktop.
- **Rationale**: Provides cashiers and operators with an intuitive, muscle-memory navigation flow without cluttering screen real estate.

### 8. Dashboard Symbol-Only Period Filter Button
- **Decision**: Render a compact, symbol-only filter button on the executive dashboard to switch time periods (`today`, `yesterday`, `7days`, `this_month`, `last_month`).
- **Rationale**: Eliminates bulky dropdown selectors from the primary KPI header, maintaining a clean visual hierarchy.

---

## 2. Environment Configuration & Ports

| Application / Service | Local Development Port | Production Domain | Tech Stack |
|---|---|---|---|
| **Store POS Frontend** | `http://localhost:5173/` | `https://app.dreamwithtech.dev/` | React 19, Vite 8, Tailwind v4 |
| **Company Admin Portal**| `http://localhost:5174/` | `https://admin.dreamwithtech.dev/` | React 19, Vite 6, Pure CSS |
| **RESTful API Backend** | `http://localhost:8000/` | `https://api.dreamwithtech.dev/` | Django 4.2.16, DRF 3.15, Gunicorn |
| **PostgreSQL Database** | Port `5432` | Managed Cloud PostgreSQL 15 | `psycopg` 3.x / `dj-database-url` |

### Environment Variables (.env)
```bash
# Django Core
SECRET_KEY=your-django-production-secret-key
DEBUG=False
ALLOWED_HOSTS=api.dreamwithtech.dev,app.dreamwithtech.dev,admin.dreamwithtech.dev,localhost,127.0.0.1

# Database Routing
DATABASE_URL=postgres://user:password@hostname:5432/billing_erp_db

# SimpleJWT
JWT_SECRET_KEY=your-jwt-signing-key
ACCESS_TOKEN_LIFETIME_MINUTES=60
REFRESH_TOKEN_LIFETIME_DAYS=14

# Payment Gateway (Razorpay)
RAZORPAY_KEY_ID=rzp_live_xxxxxxxxxxxxxx
RAZORPAY_KEY_SECRET=xxxxxxxxxxxxxxxxxxxxxxxx
RAZORPAY_WEBHOOK_SECRET=whsec_xxxxxxxxxxxxxxxxxxxx

# Communications (Twilio)
TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
TWILIO_AUTH_TOKEN=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
TWILIO_WHATSAPP_NUMBER=whatsapp:+14155238886
TWILIO_SMS_NUMBER=+1234567890

# Cloud Storage (Supabase S3)
SUPABASE_URL=https://xxxxxxxxxxxx.supabase.co
SUPABASE_KEY=your-supabase-service-role-key
SUPABASE_BUCKET=billing-documents
```

---

## 3. Important Database Migrations

- **`api.0039_business_shop_id_and_retiredshopid`**:
  - Adds `shop_id` field to `Business` model (`CharField(max_length=7, unique=True)`).
  - Populates existing businesses with retroactively generated unique 7-character IDs.
  - Creates the `RetiredShopID` table and establishes uniqueness enforcement.
  - Fix note: Avoid raw PostgreSQL table duplication by letting Django handle index generation without duplicate `_like` operators.

---

## 4. Source of Truth Directory Reference

When locating specific business logic or utilities, consult these exact files:

| Capability / Domain | Source of Truth File |
|---|---|
| **Invoice Math & Concurrency** | `backend/api/services/invoice_service.py` |
| **GST Splits & Margin Formulas**| `backend/api/calculations.py` |
| **Payment Collections & TXN ID**| `backend/api/services/payment_service.py` |
| **Audit Log Generator** | `backend/api/models.py` (`AuditLog.log_action`) |
| **ReportLab PDF Generator** | `backend/api/pdf_utils.py` |
| **Indian Number Formatting** | `frontend/src/utils/formatters.js` & `admin-frontend/src/utils/formatters.js` |
| **POS Keyboard Bindings** | `frontend/src/pages/NewBill.jsx` |
| **Admin SaaS Mock Persistence**| `admin-frontend/src/services/adminService.js` |
| **Admin Route Table** | `admin-frontend/src/routes/AppRoutes.jsx` |
| **Admin Enterprise CSS** | `admin-frontend/src/styles/variables.css` |

