# Development Rules, Coding Standards & AI Agent Guidelines

**Scope**: Applicable to all human engineers and AI coding assistants (Cursor, Claude Code, GitHub Copilot, Gemini) working on the **DreamWithTech Billing ERP** codebase.  
**Strict Principle**: This document is an active policy contract. Any code violating these rules must be rejected during review.

---

## 1. Cardinal Engineering Principles

1. **Absolute Accounting & Ledger Integrity**:
   - Financial figures must never use binary floating-point numbers (`float`). Always use Python's `Decimal` with explicit 2-place rounding (`ROUND_HALF_UP`) and database `DecimalField(max_digits=12, decimal_places=2)`.
   - Never perform destructive updates on financial ledgers (`CustomerLedger`, `SupplierLedger`, `Payment`). Corrections must be recorded as compensatory credit notes or debit notes.
   - Enforce database check constraints (`debit = 0 OR credit = 0`) to prevent two-sided corrupted transactions.

2. **Strict Multi-Tenant Isolation**:
   - Every domain query in the backend must filter strictly by the authenticated user's business (`business=request.user.business`).
   - Cross-tenant lookups or mutations are considered critical security vulnerabilities.
   - Platform-level administration actions must be executed exclusively via `admin-frontend` or dedicated SuperAdmin endpoints (`/api/auth/super-admin/`).

3. **7-Character Unique Shop ID Invariance**:
   - Every shop ID must strictly match the regex pattern: `^DW[A-Z]{2}[0-9]{4}$` (`DWAAYYNN`).
   - Shop IDs are generated exclusively on the backend upon store creation.
   - Shop IDs are permanent and immutable. Never add endpoints or serializer fields allowing manual editing of Shop IDs.
   - Retired Shop IDs (`RetiredShopID`) must never be recycled.

4. **Permanent Transaction ID Invariance**:
   - A payment collection transaction ID (`TXN-...`) must be generated **only upon collection of payment**.
   - Transaction IDs cannot be modified, deleted, or pre-generated before funds are received.
   - Every payment collection must capture an immutable historical record in `Payment` and `CustomerPayment`.

5. **Technology Stack Boundaries (Strict Rule)**:
   - **`frontend/` (Store POS)**: Uses React 19 + Vite 8 + **Tailwind CSS v4**.
   - **`admin-frontend/` (Company Admin)**: Uses React 19 + Vite 6 + **STRICTLY PURE CSS / CSS CUSTOM PROPERTIES**. **DO NOT USE TAILWIND CSS** in `admin-frontend/`.

---

## 2. Backend Coding Standards (Python & Django)

### 1. Style & Architecture
- Adhere strictly to **PEP 8** formatting with 4-space indentation.
- Keep business logic in encapsulated domain services (`backend/api/services/`), not in views or models.
  - `invoice_service.py`: Invoice creation, line item calculation, stock deduction, and status transitions.
  - `payment_service.py`: Payment collections, permanent transaction ID assignment, and Khata updates.
  - `notification_service.py`: Alert generation, deduplication, and automated checks.
  - `calculations.py`: Pure functional financial formulas (statutory GST splits, profit margins, round-offs).
- Views must remain thin, handling request validation, permission checks, delegation to services, and standardized JSON responses.

### 2. Database & ORM Safety
- Always wrap operations involving inventory deduction and financial ledgers inside `transaction.atomic()`.
- Use `select_for_update()` when checking and deducting stock counts to prevent race conditions during concurrent checkouts.
- Never use `.delete()` on models supporting soft deletion (`Product`, `Customer`, `Supplier`, `Category`). Use `.soft_delete()` or update `is_active=False` / `is_deleted=True`.
- Always provide explicit `related_name` on Foreign Key relationships to avoid ambiguous reverse lookups.

### 3. API Serialization & Validation
- Validate incoming data using DRF serializers with explicit error messages.
- Always use `Decimal` instances for decimal field validators (avoid `min_value=0.0`; use `min_value=Decimal('0.00')` to avoid runtime warnings).
- Sanitize user inputs:
  - Phone numbers: Standardize to 10-digit Indian mobile format (`^[6-9]\d{9}$`).
  - GSTIN: Validate against 15-character statutory format (`^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$`).
  - HSN Codes: 4, 6, or 8 digits.

---

## 3. Frontend Coding Standards (React)

### 1. Store POS Application (`frontend/`)
- **Framework**: React 19 with functional components and modern hooks (`useState`, `useEffect`, `useCallback`, `useMemo`, `useRef`).
- **Styling**: Tailwind CSS v4 utility classes.
- **Keyboard Ergonomics**: All POS checkout actions must support keyboard shortcuts (`F1` through `F8`). Never disable keyboard accessibility for checkout controls.
- **Number Formatting**: Always use centralized utilities from `frontend/src/utils/formatters.js`:
  ```javascript
  import { formatCurrency, formatNumber, formatPercent, formatDate } from '../utils/formatters';
  // formatCurrency(125000) -> "₹1,25,000.00"
  // formatNumber(125000)   -> "1,25,000"
  // formatPercent(18)      -> "18.00%"
  ```
- **Tabular Alignment**: Every financial figure, stock quantity, invoice number, and timestamp must use monospaced tabular numerals (`font-mono tabular-nums`).
- **Back Navigation**: Provide a simple text-format Back button on all pages with proper navigation flow across both desktop and mobile views.
- **Header Badges**: Display the 7-character Shop ID (`DWAAYYNN`) and statutory GSTIN (if registered) on the layout top bar.

### 2. Company Admin Dashboard (`admin-frontend/`)
- **Styling Constraint**: Pure CSS only (`src/styles/variables.css`, `layout.css`, `components.css`, `tables.css`). **Never install or import Tailwind CSS in `admin-frontend/`**.
- **Palette Tokens**: Use CSS custom variables (`var(--primary)`, `var(--bg-page)`, `var(--text-main)`, `var(--border)`).
- **Service Layer**: Keep all mock data interactions encapsulated in `src/services/adminService.js` with `localStorage` synchronization until backend API integration is ready.
- **Responsive Navigation**: Support mobile toggle drawers while maintaining an enterprise navy-slate desktop sidebar.

---

## 4. Security & Compliance Rules

1. **Authentication & Token Management**:
   - Access tokens must use `Bearer <token>` in the `Authorization` header.
   - Tokens must be stored in secure storage (`localStorage` for web clients, with refresh tokens cycled on expiry).
   - Never expose passwords, secret keys, or payment gateway API secrets in frontend bundles or API response payloads.

2. **Role-Based Access Control (RBAC)**:
   - Cashiers must never be granted permissions to:
     - View gross/net store profit margins.
     - Alter master product purchase cost prices.
     - Void or cancel historical invoices without manager authorization.
     - Purge items from the Recycle Bin.
   - Every sensitive endpoint must enforce permission classes (`IsOwnerOrAdmin`, `IsManagerOrAbove`).

3. **Audit Logging Enforcement**:
   - Every destructive action (cancellations, refunds, price overrides, stock write-offs, staff role changes) must create an `AuditLog` entry.
   - Captured details must include operator user ID, client IP address, action code, target resource, and JSON state diff.

---

## 5. Guidelines for AI Coding Agents (Cursor, Claude Code, Copilot)

When modifying or extending this codebase, AI assistants must adhere to the following rules:

1. **Inspect Before Modifying**:
   - Always read existing models (`backend/api/models.py`), serializers (`backend/api/serializers.py`), and service modules before adding new endpoints or fields.
   - Never duplicate existing logic. Check `invoice_service.py`, `payment_service.py`, `notification_service.py`, and `calculations.py`.

2. **Preserve Documentation & Comments**:
   - Never delete or truncate existing architectural comments, docstrings, or documentation files unless explicitly requested by the user.

3. **No Phantom Implementations**:
   - Do not claim a feature is complete if it has only been partially stubbed.
   - Do not invent mock endpoints that do not exist in `api/urls.py`.

4. **Sandbox & Tool Execution**:
   - Always run commands in standard sandbox mode first (`BypassSandbox: false`). Only request bypass when external network access is genuinely required (e.g., initial package installations).
   - Never execute destructive database scripts without verifying existing migrations.

5. **Maintain Cross-File Synchronization**:
   - When modifying database models, always create and verify Django migrations (`python manage.py makemigrations` and `python manage.py migrate`).
   - When altering API request/response structures, update both the DRF serializers and the corresponding frontend API client methods.
   - Keep the six documents in `docs/` synchronized with any architectural changes.

